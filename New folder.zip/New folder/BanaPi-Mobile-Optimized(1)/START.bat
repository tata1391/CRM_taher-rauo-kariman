@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
    py server.py
    goto :eof
)
where python >nul 2>nul
if %errorlevel%==0 (
    python server.py
    goto :eof
)
echo Python نصب نیست. لطفا Python 3 را نصب کنید یا پروژه را با Live Server اجرا کنید.
pause
