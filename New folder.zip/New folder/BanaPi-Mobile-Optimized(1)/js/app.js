/* ============================================================
   بناپی — Application Engine
   Router · Renderers · RBAC · Workflows · Automation · AI
   ============================================================ */
'use strict';

/* ---------------- Persistence & State ---------------- */
const STORE = {
    user: null,
    page: 'dashboard',
    params: {},
    customers: CUSTOMERS.map(c => ({ ...c })),
    products: PRODUCTS.map(p => ({ ...p })),
    invoices: INVOICES.map(i => ({ ...i })),
    checks: CHECKS.map(c => ({ ...c })),
    deals: DEALS.map(d => ({ ...d })),
    tasks: TASKS.map(t => ({ ...t })),
    notifs: NOTIFS.map(n => ({ ...n })),
    messages: MESSAGES.map(m => ({ ...m })),
    audit: AUDIT_LOG.map(a => ({ ...a })),
    workflows: WORKFLOWS.map(w => ({ nodes: w.nodes.map(n => ({ ...n })), ...w })),
    chat: [],
    calMonth: 'مهر',
    searchOpen: false,
    dragDeal: null,
    journal: [],
};

/* ---------------- Helpers ---------------- */
const PD = '۰۱۲۳۴۵۶۷۸۹';
function faNum(v) {
    if (v === undefined || v === null) return '';
    let s = String(typeof v === 'number' ? (Number.isInteger(v) ? v : Math.round(v * 100) / 100) : v);
    const parts = s.split('.');
    const int = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, '٬').replace(/\d/g, d => PD[d]);
    return parts[1] !== undefined ? int + '٫' + parts[1].replace(/\d/g, d => PD[d]) : int;
}
function faMoney(n) {
    const v = Number(n) || 0;
    if (v === 0) return '۰ تومان';
    if (v >= 1e9) return faNum((v / 1e9).toFixed(1)) + ' میلیارد تومان';
    if (v >= 1e6) return faNum(Math.round(v / 1e6)) + ' میلیون تومان';
    if (v >= 1000) return faNum(Math.round(v / 1000)) + ' هزار تومان';
    return faNum(Math.round(v)) + ' تومان';
}
function faMv(n) { return faNum(Math.round(n)) + ' میلیون تومان'; }
function userOf(id) { return USERS.find(u => u.id === id) || USERS[0]; }
function customerOf(id) { return STORE.customers.find(c => c.id === id); }
function cmpName(id) { const c = customerOf(id); return c ? c.company : ''; }
function pillColor(st) { return { paid: 'green', partial: 'amber', unpaid: 'red', passed: 'green', pending: 'amber', low: 'amber', ok: 'green', active: 'green', follow: 'amber', lead: 'cyan', dormant: 'gray' }[st] || 'gray'; }
function prClass(p) { return { low: 'pr-low', medium: 'pr-med', high: 'pr-high', urgent: 'pr-urg' }[p] || 'pr-med'; }
function prLabel(p) { return { low: 'کم', medium: 'متوسط', high: 'زیاد', urgent: 'فوری' }[p] || p; }
const CAT_EMOJI = { 'میلگرد': '🏗️', 'پروفیل': '📐', 'ورق': '🧱', 'سیمان': '🪨', 'سایر': '📦' };
const PRODUCT_ICONS = ['🏗️', '📐', '🧱', '🪨', '📦', '🔩', '🛠️', '🚚', '🛒', '🏢'];
const TASK_ICONS = ['📌', '📞', '📦', '🧾', '💰', '🗓️', '🔧', '🚀', '✅', '📍'];
function featInfo(k) { return PRODUCT_FEATURES.find(f => f.key === k) || { key: k, label: k }; }
function featLabel(k) { return featInfo(k).label; }
function featBadges(list) { return (list || []).map(k => `<span class="feat-tag">${featLabel(k)}</span>`).join(''); }
function prodIcon(p) { return (p && p.icon) || CAT_EMOJI[(p && p.cat) || ''] || '📦'; }
function taskIcon(t) { return (t && t.icon) || '📌'; }

/* ---------------- Icons ---------------- */
const I = {
    dash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg>',
    users: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
    target: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>',
    cart: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>',
    box: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>',
    doc: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>',
    coin: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v12"/><path d="M16 8.5c0-1.4-1.8-2.5-4-2.5s-4 1.1-4 2.5 1.8 2.2 4 2.5 4 1.1 4 2.5-1.8 2.5-4 2.5-4-1.1-4-2.5"/></svg>',
    bank: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="22" x2="21" y2="22"/><path d="M1 8l11-5 11 5L12 13 1 8z"/><path d="M5 10v8M9 10v8M15 10v8M19 10v8"/></svg>',
    task: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>',
    calendar: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>',
    chart: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>',
    spark: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2l2 6 6 2-6 2-2 6-2-6-6-2 6-2z"/><path d="M19 15l1 3 3 1-3 1-1 3-1-3-3-1 3-1z"/></svg>',
    robot: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="8" width="16" height="12" rx="2"/><path d="M12 8V4"/><circle cx="12" cy="14" r="2"/><line x1="8" y1="18" x2="8" y2="20"/><line x1="16" y1="18" x2="16" y2="20"/><circle cx="8.5" cy="11" r=".8"/><circle cx="15.5" cy="11" r=".8"/></svg>',
    gear: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
    bell: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>',
    msg: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>',
    search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>',
    phone: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>',
    note: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4z"/></svg>',
    clock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>',
    pin: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>',
    mail: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>',
    tag: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>',
    file: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h7"/><polyline points="21 6 12 15 8 11"/></svg>',
    send: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>',
    off: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>',
    plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>',
    warn: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
    head: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><line x1="20" y1="8" x2="20" y2="14"/><line x1="23" y1="11" x2="17" y2="11"/></svg>',
    eye: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>',
    x: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
    up: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><polyline points="23 18 13.5 8.5 8.5 13.5 1 6"/><polyline points="17 18 23 18 23 12"/></svg>',
    down: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>',
    mini: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>',
    chev: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg>',
    check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><polyline points="20 6 9 17 4 12"/></svg>',
    fire: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22c4.4 0 8-3.6 8-8 0-5-4-9-8-12-1 3-3 4.5-3 6.5C9 8 11 10 11 12c0-1-1-2-1-3 0-1.7 1-3 1-3.5 -2.5 1-5 4-5 7.5 0 4.4 3.6 8 6 8z" fill="currentColor" stroke="none"/></svg>',
    sms: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/><path d="M8 9h8M8 13h5"/></svg>',
};
for (const k in I) I[k] = I[k].replace(/stroke-width="2"/g, 'stroke-width="2"');

/* ---------------- Page registry ---------------- */
const PAGES = {
    dashboard:  { title: 'داشبورد مدیریتی', crumb: 'خانه / داشبورد' },
    customers:  { title: 'مشتریان CRM', crumb: 'مشتریان / لیست مشتریان' },
    pipeline:   { title: 'فرصت‌های فروش', crumb: 'فروش / قیف فروش' },
    purchase:   { title: 'خرید و تامین', crumb: 'عملیات / خرید و تامین' },
    inventory:  { title: 'انبار و موجودی', crumb: 'عملیات / انبار' },
    invoices:   { title: 'فاکتورها', crumb: 'مالی / فاکتورها' },
    accounting: { title: 'حسابداری', crumb: 'مالی / حسابداری' },
    checks:     { title: 'چک‌ها', crumb: 'مالی / چک‌ها' },
    tasks:      { title: 'وظایف و پروژه‌ها', crumb: 'همکاری / وظایف' },
    calendar:   { title: 'تقویم جلسات', crumb: 'همکاری / تقویم' },
    reports:    { title: 'گزارش‌ها', crumb: 'تحلیل / مرکز گزارش‌ها' },
    automation: { title: 'اتوماسیون هوشمند', crumb: 'هوش / اتوماسیون' },
    ai:         { title: 'دستیار هوش مصنوعی', crumb: 'هوش / دستیار' },
    settings:   { title: 'تنظیمات', crumb: 'سیستم / تنظیمات' },
    notifications: { title: 'مرکز اعلان‌ها', crumb: 'سیستم / اعلان‌ها' },
};

/* ---------------- Sidebar ---------------- */
function can(page) {
    if (!STORE.user) return false;
    const list = PERMISSIONS[STORE.user.role] || [];
    if (list.includes('*')) return true;
    if (page === 'notifications') return true;
    return list.includes(page);
}
function buildNav() {
    const groups = [
        { sec: 'نقشه سازمان', items: [
            ['dashboard', 'داشبورد', 'dash', ''], ['customers', 'مشتریان CRM', 'users', ''], ['pipeline', 'فرصت‌های فروش', 'target', ''],
        ]},
        { sec: 'عملیات', items: [
            ['purchase', 'خرید و تامین', 'cart', ''], ['inventory', 'انبار و موجودی', 'box', ''], ['invoices', 'فاکتورها', 'doc', ''],
        ]},
        { sec: 'مالی', items: [
            ['accounting', 'حسابداری', 'coin', ''], ['checks', 'چک‌ها', 'bank', ''],
        ]},
        { sec: 'همکاری', items: [
            ['tasks', 'وظایف و پروژه‌ها', 'task', ''], ['calendar', 'تقویم جلسات', 'calendar', ''],
        ]},
        { sec: 'هوش و تحلیل', items: [
            ['reports', 'گزارش‌ها', 'chart', ''], ['automation', 'اتوماسیون', 'spark', ''], ['ai', 'دستیار هوش مصنوعی', 'robot', ''],
        ]},
    ];
    let html = '';
    for (const g of groups) {
        const items = g.items.filter(i => can(i[0]));
        if (!items.length) continue;
        html += `<div class="nav-section">${g.sec}</div>`;
        for (const [page, label, icon, badge] of items) {
            const count = page === 'inventory' ? STORE.products.filter(p => p.status === 'low').length : '';
            const bdg = badge || (count ? `<span class="nav-badge">${faNum(count)}</span>` : '');
            const cls = STORE.page === page ? ' active' : '';
            html += `<a href="#" class="nav-item${cls}" data-page="${page}" onclick="navigateTo('${page}')">
                <span class="nav-ic">${I[icon]}</span><span>${label}</span>${bdg}
            </a>`;
        }
    }
    const st = `<div class="nav-section">سیستم</div>
        <a href="#" class="nav-item ${STORE.page === 'settings' ? 'active' : ''}" onclick="navigateTo('settings')"><span class="nav-ic">${I.gear}</span><span>تنظیمات</span></a>`;
    return html + st;
}
function renderSidebar() {
    document.getElementById('sidebarNav').innerHTML = buildNav();
    const u = userOf(STORE.user.id);
    document.getElementById('sidebarAvatar').innerHTML = `<span>${u.initials}</span>`;
    document.getElementById('sidebarUserName').textContent = u.name;
    document.getElementById('sidebarUserRole').textContent = ROLES[u.role].label;
}

/* ---------------- Topbar ---------------- */
function faToday() {
    try {
        return new Intl.DateTimeFormat('fa-IR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).format(new Date());
    } catch (e) {
        return 'چهارشنبه ۲ مهر ۱۴۰۵';
    }
}
function refreshTopbar() {
    document.getElementById('topbarDate').textContent = faToday();
    const u = userOf(STORE.user.id);
    document.getElementById('topbarAvatar').innerHTML = `<span>${u.initials}</span>`;
    document.getElementById('topbarUserName').textContent = u.name;
    document.getElementById('topbarUserRole').textContent = ROLES[u.role].label;
    const unread = STORE.notifs.filter(n => !n.read).length;
    const dot = document.getElementById('notifCount');
    dot.textContent = faNum(unread);
    dot.style.display = unread ? 'grid' : 'none';
}
function renderNotifPanel() {
    const unread = STORE.notifs.filter(n => !n.read).length;
    document.getElementById('notifUnread').textContent = faNum(unread) + ' خوانده‌نشده';
    document.getElementById('notifList').innerHTML = STORE.notifs.slice(0, 6).map(n => `
        <div class="pop-item ${n.read ? 'read' : 'unread'}" onclick="markNotifRead('${n.id}')">
            <div class="pop-icon" style="background:${notifStyle(n.type).bg};color:${notifStyle(n.type).fg}">${I[notifStyle(n.type).icon]}</div>
            <div style="min-width:0">
                <div class="pi-t">${n.title}</div><div class="pi-b">${n.body}</div><div class="pi-time">${n.time}</div>
            </div>
            <span class="pi-dot"></span>
        </div>`).join('') + `
        <div class="pop-item" onclick="navigateTo('notifications')" style="justify-content:center;color:var(--cyan-300);font-size:.78rem;font-weight:700">
            مشاهده همه اعلان‌ها ←
        </div>`;
}
function renderMsgPanel() {
    document.getElementById('msgList').innerHTML = STORE.messages.map(m => `
        <div class="pop-item">
            <div class="avatar-ring sm">${m.initials}</div>
            <div style="min-width:0">
                <div class="pi-t">${m.from}</div><div class="pi-b">${m.text}</div><div class="pi-time">${m.time}</div>
            </div>
        </div>`).join('');
}
function notifStyle(t) {
    return { inventory: { icon: 'box', fg: '#FBBF24', bg: 'rgba(251,191,36,.15)' }, finance: { icon: 'coin', fg: '#34D399', bg: 'rgba(52,211,153,.15)' }, task: { icon: 'task', fg: '#818CF8', bg: 'rgba(129,140,248,.15)' }, crm: { icon: 'users', fg: '#00C8FF', bg: 'rgba(0,200,255,.14)' }, system: { icon: 'gear', fg: '#94A3B8', bg: 'rgba(148,163,184,.15)' } }[t] || { icon: 'bell', fg: '#00C8FF', bg: 'rgba(0,200,255,.14)' };
}
function togglePanel(id) {
    const el = document.getElementById(id);
    const open = el.classList.contains('open');
    document.querySelectorAll('.head-pop-wrap.open').forEach(w => w.classList.remove('open'));
    if (!open) el.classList.add('open');
}
document.addEventListener('click', () => {
    document.querySelectorAll('.head-pop-wrap.open').forEach(w => w.classList.remove('open'));
});
function markAllRead() { STORE.notifs.forEach(n => n.read = true); renderNotifPanel(); refreshTopbar(); showToast('info', 'همه اعلان‌ها خوانده شد'); }
function markNotifRead(id) { const n = STORE.notifs.find(x => x.id === id); if (n) n.read = true; renderNotifPanel(); refreshTopbar(); }

/* ---------------- Toasts & Modal ---------------- */
function showToast(type, title, body) {
    const c = document.getElementById('toastContainer');
    const el = document.createElement('div');
    el.className = 'toast t-' + type;
    const ic = { success: 'check', info: 'bell', warn: 'warn', error: 'x' }[type] || 'bell';
    const icSvg = { check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><polyline points="20 6 9 17 4 12"/></svg>', bell: I.bell, warn: I.warn, x: I.x }[ic];
    el.innerHTML = `<div class="t-icon">${icSvg}</div><div><div class="t-title">${title}</div><div class="t-body">${body || ''}</div></div>
        <button class="t-close" onclick="this.closest('.toast').remove()">${I.x}</button>`;
    c.appendChild(el);
    setTimeout(() => { el.classList.add('out'); setTimeout(() => el.remove(), 350); }, 4600);
}
function openModal(html) {
    document.getElementById('modalShell').innerHTML = html;
    document.getElementById('modalOverlay').classList.add('open');
}
function closeModal() { document.getElementById('modalOverlay').classList.remove('open'); }

/* ---------------- Data wipe (start from zero) ---------------- */
function confirmWipe() {
    openModal(`
        <div class="modal-head"><h3>${I.warn} پاکسازی کامل داده‌ها</h3><button class="modal-close" onclick="closeModal()">${I.x}</button></div>
        <div class="modal-body">
            <div class="empty-state">${I.warn}<div class="es-t">عملیات غیرقابل بازگشت</div>همه مشتریان، تامین‌کنندگان، فاکتورها، هزینه‌ها، چک‌ها، فرصت‌های فروش، وظایف، اعلان‌ها، جلسات و گزارش‌ها برای همیشه حذف می‌شوند. این کار قابل بازگشت نیست.</div>
        </div>
        <div class="modal-foot"><button class="btn btn-ghost" onclick="closeModal()">انصراف</button><button class="btn btn-danger" onclick="wipeAllData()">${I.warn} بله، همه را پاک کن</button></div>`);
}
function wipeAllData() {
    STORE.customers.length = 0;
    STORE.invoices.length = 0;
    STORE.checks.length = 0;
    STORE.deals.length = 0;
    STORE.tasks.length = 0;
    STORE.notifs.length = 0;
    STORE.messages.length = 0;
    STORE.audit.length = 0;
    STORE.chat.length = 0;
    SUPPLIERS.length = 0;
    EMP_PERF.length = 0;
    MEETINGS.length = 0;
    for (const k in SERIES) SERIES[k].fill(0);
    EXPENSE_CATS.forEach(c => c.value = 0);
    INCOME_CATS.forEach(c => c.value = 0);
    PIPELINE_STAGES.forEach(s => s.value = 0);
    STORE.dragDeal = null;
    STORE.dragTask = null;
    closeModal();
    if (STORE.user) { renderNotifPanel(); refreshTopbar(); }
    showToast('success', 'پاکسازی کامل انجام شد', 'همه داده‌های قبلی حذف شدند؛ سامانه از صفر شروع می‌کند');
    renderPage();
}

/* ---------------- Audit & Notifications engine ---------------- */
function logAudit(action, module) {
    STORE.audit.unshift({ user: (STORE.user && userOf(STORE.user.id).name) || 'سیستم', action, date: '۱۴۰۵-۰۷-۰۲', time: new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }), module });
    if (STORE.audit.length > 60) STORE.audit.pop();
}
function addNotif(type, title, body, time) {
    STORE.notifs.unshift({ id: 'n' + Date.now(), type, icon: notifStyle(type).icon, title, body, time: time || 'لحظاتی پیش', read: false });
    renderNotifPanel(); refreshTopbar();
}
function ensureNotif(type, title) {
    const exists = STORE.notifs.some(n => n.title === title);
    if (exists) return;
    addNotif(type, title, '');
}

/* ---------------- Automation Engine ---------------- */
function automationActions(wf) {
    const results = [];
    for (const node of wf.nodes) {
        if (node.type !== 'action') continue;
        const t = node.text;
        if (t.includes('وظیفه')) {
            STORE.tasks.unshift({ id: 't' + Date.now(), title: 'وظیفه خودکار: ' + t, descr: 'تولید شده توسط اتوماسیون «' + wf.name + '»', assignee: STORE.user.id, creator: 'auto', priority: 'medium', status: 'todo', due: '2026-09-26', ref: 'اتوماسیون', customer: '', tags: ['اتوماسیون'] });
            results.push({ ok: true, text: 'ایجاد شد: وظیفه «' + t + '»' });
        } else if (t.includes('اعلان')) {
            addNotif('system', 'اتوماسیون: ' + t, 'گردش کار «' + wf.name + '» اجرا شد');
            results.push({ ok: true, text: 'اعلان ارسال شد: ' + t });
        } else if (t.includes('زمان‌بندی') || t.includes('یادآوری')) {
            addNotif('task', 'یادآوری زمان‌بندی‌شده', 'گردش کار «' + wf.name + '» — ' + t);
            results.push({ ok: true, text: 'پیگیری برنامه‌ریزی شد: ' + t });
        } else if (t.includes('پیام')) {
            results.push({ ok: true, text: 'پیام به مخاطب ارسال شد: ' + t });
        } else if (t.includes('درخواست')) {
            results.push({ ok: true, text: 'درخواست ثبت شد: ' + t });
        } else {
            results.push({ ok: true, text: 'اقدام انجام شد: ' + t });
        }
    }
    return results;
}
function runWorkflow(wf) {
    logAudit('گردش کار «' + wf.name + '» اجرا شد', 'اتوماسیون');
    return automationActions(wf);
}
function triggerAutomations(eventKey, ctxText) {
    const fired = [];
    for (const wf of STORE.workflows) {
        if (!wf.enabled) continue;
        if (wf.trigger.includes(eventKey)) {
            fired.push({ wf, results: automationActions(wf) });
        }
    }
    return fired;
}

/* ---------------- System checks ---------------- */
function systemChecks() {
    // Low stock
    STORE.products.forEach(p => {
        if (p.qty > 0 && p.qty < p.minStock) {
            ensureNotif('inventory', 'موجودی ' + p.name + ' کم شده است');
        }
    });
    const fired = triggerAutomations('موجودی کالا زیر حد مجاز شد', 'low stock');
    // Check due in 3 days
    const dueToday = new Date('2026-09-23');
    STORE.checks.forEach(ch => {
        const d = new Date(ch.dueDate);
        const days = Math.round((d - dueToday) / 86400000);
        if (ch.status === 'pending' && days >= 0 && days <= 3) {
            ensureNotif('finance', 'سررسید چک ' + ch.id + ' نزدیک است');
        }
    });
    // Overdue follow-up tasks
    STORE.tasks.forEach(t => {
        if (t.status !== 'done' && t.ref === 'اتوماسیون' && t.due < '2026-09-23') {
            ensureNotif('task', 'وظیفه «' + t.title + '» دیر شده است');
        }
    });
}

/* ============================================================
   RENDER: DASHBOARD
   ============================================================ */
function sparkline(arr, color) {
    const max = Math.max(...arr), min = Math.min(...arr), n = arr.length;
    const w = 92, h = 32, pad = 2;
    const pts = arr.map((v, i) => {
        const x = pad + (i * (w - pad * 2) / (n - 1));
        const y = h - pad - ((v - min) / (max - min || 1)) * (h - pad * 2);
        return `${x.toFixed(1)},${y.toFixed(1)}`;
    });
    const last = arr[arr.length - 1], first = arr[0];
    const delta = first === 0 ? 0 : ((last - first) / Math.abs(first)) * 100;
    return `<svg class="spark" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}">
        <defs><linearGradient id="sg${color.slice(1)}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${color}" stop-opacity=".35"/><stop offset="1" stop-color="${color}" stop-opacity="0"/></linearGradient></defs>
        <polygon points="0,${h} ${pts.join(' ')} ${w},${h}" fill="url(#sg${color.slice(1)})"/>
        <polyline points="${pts.join(' ')}" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>`;
}
function kpiCard(label, num, sub, delta, up, icon, color, spark) {
    return `<div class="glass-card kpi-card hover" style="--kpi-color:${color};--kpi-glow:${color}22;--kpi-bg:linear-gradient(135deg, ${color}33, transparent)">
        <div class="kpi-top">
            <span class="kpi-label">${label}</span>
            <div class="kpi-icon">${I[icon]}</div>
        </div>
        <div class="kpi-num">${num}</div>
        <div class="kpi-foot">
            <div>
                <span class="kpi-delta ${up ? 'up' : 'down'}">${up ? I.up : I.down} ${delta}</span>
                <div class="kpi-note">${sub}</div>
            </div>
            ${spark || ''}
        </div>
    </div>`;
}
function kpis() {
    const receivables = STORE.customers.reduce((s, c) => s + (c.balance || 0), 0);
    const payables = SUPPLIERS.reduce((s, p) => s + (p.balance || 0), 0);
    const invValue = STORE.products.reduce((s, p) => s + p.qty * p.avgCost, 0);
    const activeCust = STORE.customers.filter(c => c.status === 'active').length;
    const profit = SERIES.profit[11] * 1e6;
    return `
    <div class="grid kpis">
        ${kpiCard('فروش امروز', faMoney(0), 'نسبت به دیروز', '۰٪', true, 'coin', '#00C8FF', sparkline([0,0,0,0,0,0,0,0], '#00C8FF'))}
        ${kpiCard('خرید امروز', faMoney(0), 'نسبت به دیروز', '۰٪', false, 'cart', '#818CF8', sparkline([0,0,0,0,0,0,0,0], '#818CF8'))}
        ${kpiCard('سود خالص', faMoney(profit), 'سود فروش ماه جاری', '۰٪', true, 'chart', '#34D399', sparkline(SERIES.profit.slice(3), '#34D399'))}
        ${kpiCard('موجودی انبار', faMoney(invValue), 'ارزش بر اساس بهای تمام‌شده', '۰٪', true, 'box', '#006BFF', sparkline([0,0,0,0,0,0,0,0], '#006BFF'))}
        ${kpiCard('مشتریان فعال', faNum(activeCust) + ' <small>مشتری</small>', 'از مجموع ' + faNum(STORE.customers.length) + ' مشتری', '۰ نفر', true, 'users', '#8B5CF6', sparkline(SERIES.customers.slice(3), '#8B5CF6'))}
        ${kpiCard('مطالبات', faMoney(receivables), 'بدهی پرداخت‌نشده مشتریان', '۰٪', false, 'bank', '#F43F5E', sparkline([0,0,0,0,0,0,0,0], '#F43F5E'))}
    </div>`;
}
function pageDashboard() {
    const low = STORE.products.filter(p => p.status === 'low');
    const lastInv = STORE.invoices.filter(i => i.type === 'فروش').slice(0, 5);
    const act = STORE.audit.slice(0, 5);
    return `
    <div class="page-head">
        <div><h2>${PAGES.dashboard.title}</h2><div class="sub">سلام ${userOf(STORE.user.id).name} عزیز، این وضعیت امروز شرکت است. <span class="dot-live"></span> سیستم فعال</div></div>
        <div class="page-head-actions">
            <button class="btn btn-ghost" onclick="navigateTo('reports')">${I.chart} گزارش کامل</button>
            <button class="btn btn-primary" onclick="openNewSaleModal()">${I.plus} ثبت فروش جدید</button>
        </div>
    </div>
    ${kpis()}
    <div class="grid cols-2-1 mb-3">
        <div class="glass-card chart-panel panel">
            <div class="panel-head"><div class="panel-title"><span class="pt-icon">${I.chart}</span> فروش و خرید ماهانه (میلیون تومان)</div><span class="panel-more">آخرین ۱۲ ماه</span></div>
            <div style="height:260px"><canvas id="chSales"></canvas></div>
        </div>
        <div class="grid" style="align-content:start">
            <div class="glass-card chart-panel panel">
                <div class="panel-head"><div class="panel-title"><span class="pt-icon">${I.coin}</span> سود خالص ماهانه</div></div>
                <div style="height:130px"><canvas id="chProfit"></canvas></div>
            </div>
            <div class="glass-card panel">
                <div class="panel-head"><div class="panel-title"><span class="pt-icon" style="background:var(--amber-dim);color:var(--amber)">${I.warn}</span> هشدار موجودی</div></div>
                ${low.length ? low.map(p => `<div class="ledger-item"><div class="li-icon" style="background:var(--amber-dim);color:var(--amber)">${I.box}</div><div class="li-main"><div class="li-t">${p.name}</div><div class="li-s">موجودی ${faNum(p.qty)} ${p.unit} — حداقل ${faNum(p.minStock)}</div></div><span class="pill amber">کم</span></div>`).join('') : '<div class="empty-state">همه کالاها در حد مجاز هستند</div>'}
            </div>
        </div>
    </div>
    <div class="grid cols-3">
        <div class="glass-card chart-panel panel">
            <div class="panel-head"><div class="panel-title"><span class="pt-icon">${I.users}</span> رشد مشتریان</div></div>
            <div style="height:210px"><canvas id="chGrowth"></canvas></div>
        </div>
        <div class="glass-card panel">
            <div class="panel-head"><div class="panel-title"><span class="pt-icon">${I.cart}</span> آخرین تراکنش‌ها</div></div>
            ${lastInv.map(v => `<div class="ledger-item"><div class="li-icon" style="background:${v.type === 'خرید' ? 'var(--violet-dim)':'var(--green-dim)'};color:${v.type === 'خرید' ? '#C9B8FF':'var(--green)'}">${v.type === 'خرید' ? I.cart : I.doc}</div><div class="li-main"><div class="li-t">${v.id} · ${cmpName(v.customer)}</div><div class="li-s">${v.items}</div></div><div class="li-val ${v.type === 'خرید'?'out':'in'}">${v.type === 'خرید' ? '−' : '+'}${faMoney(v.amount)}</div></div>`).join('')}
        </div>
        <div class="glass-card panel">
            <div class="panel-head"><div class="panel-title"><span class="pt-icon">${I.clock}</span> فعالیت اخیر سیستم</div></div>
            ${act.map(a => `<div class="audit-item" style="padding:9px 6px"><div class="audit-avatar" style="width:30px;height:30px;font-size:.66rem">${a.user.charAt(0)}</div><div class="audit-main"><div class="audit-action" style="font-size:.78rem">${a.action}</div><div class="audit-time">${a.time} · ${a.module}</div></div></div>`).join('')}
        </div>
    </div>`;
}
function chartsDashboard() {
    const m = MONTHS;
    mkChart('chSales', {
        type: 'line',
        data: { labels: m, datasets: [
            { label: 'فروش', data: SERIES.sales, borderColor: '#00C8FF', backgroundColor: 'rgba(0,200,255,.12)', fill: true, tension: .45, borderWidth: 2.5, pointRadius: 0, pointHoverRadius: 5 },
            { label: 'خرید', data: SERIES.purchases, borderColor: '#8B5CF6', backgroundColor: 'rgba(139,92,246,.08)', fill: true, tension: .45, borderWidth: 2, pointRadius: 0, pointHoverRadius: 5 },
        ]},
    });
    mkChart('chProfit', {
        type: 'line', data: { labels: m, datasets: [{ label: 'سود', data: SERIES.profit, borderColor: '#34D399', backgroundColor: 'rgba(52,211,153,.14)', fill: true, tension: .4, borderWidth: 2.5, pointRadius: 0 }] },
        Legend: false, Grid: true,
    });
    mkChart('chGrowth', {
        type: 'line', data: { labels: m, datasets: [{ label: 'مشتریان', data: SERIES.customers, borderColor: '#8B5CF6', backgroundColor: 'rgba(139,92,246,.12)', fill: true, tension: .4, borderWidth: 2.5, pointRadius: 0 }] },
        Legend: false, Grid: true,
    });
}

/* ============================================================
   RENDER: CRM / CUSTOMERS
   ============================================================ */
function pageCustomers() {
    const q = (STORE.params.q || '').trim();
    const st = STORE.params.status || '';
    let rows = STORE.customers;
    if (q) rows = rows.filter(c => norm(c.name + c.company + c.phone + c.project).includes(norm(q)));
    if (st) rows = rows.filter(c => c.status === st);
    return `
    <div class="page-head">
        <div><h2>${PAGES.customers.title}</h2><div class="sub">${faNum(STORE.customers.length)} مشتری ثبت‌شده · مدیریت چرخه حیات مشتری</div></div>
        <div class="page-head-actions">
            <button class="btn btn-ghost" onclick="navigateTo('pipeline')">${I.target} قیف فروش</button>
            <button class="btn btn-primary" onclick="openNewCustomerModal()">${I.plus} افزودن مشتری</button>
        </div>
    </div>
    <div class="glass-card panel">
        <div class="filter-bar">
            <div class="input-glass" style="display:flex;align-items:center;gap:8px;min-width:260px">${I.search}<input class="input-glass" style="border:none;background:none;width:100%" placeholder="جستجو در نام، شرکت، تماس، پروژه..." oninput="STORE.params.q=this.value;renderPage()"></div>
            <div class="seg">
                ${[['', 'همه'], ['active', 'فعال'], ['follow', 'در حال پیگیری'], ['lead', 'سرنخ'], ['dormant', 'خاموش']].map(([k, l]) => `<button class="${(st||'')===k?'active':''}" onclick="STORE.params.status='${k}';STORE.params.q='';renderPage()">${l}</button>`).join('')}
            </div>
        </div>
        <div class="table-wrap">
            <table class="glass-table">
                <thead><tr><th>مشتری</th><th>شرکت / پروژه</th><th>شماره تماس</th><th>نوع</th><th>آخرین خرید</th><th>مانده حساب</th><th>مرحله CRM</th><th>وضعیت</th></tr></thead>
                <tbody>
                ${rows.map(c => {

    const stage = CRM_STAGES.find(s => s.key === c.stage);
    const stLabel = { active: 'فعال', follow: 'در حال پیگیری', lead: 'سرنخ', dormant: 'خاموش' }[c.status];
    const stclz = { active: 'green', follow: 'amber', lead: 'cyan', dormant: 'gray' }[c.status];
    return `<tr onclick="navigateTo('customers', {id:'${c.id}'})">
        <td><div class="customer-row"><div class="customer-avatar c${(c.id.charCodeAt(1) % 5) + 1}">${c.name.charAt(0)}</div><div><div class="td-strong">${c.name}</div><div class="muted" style="font-size:.7rem">${c.company}</div></div></div></td>
        <td>${c.project || '—'}</td><td dir="ltr" style="text-align:right">${c.phone}</td>
        <td><span class="pill gray plain">${c.type}</span></td>
        <td>${c.lastPurchase ? faNum(c.lastPurchase.split('-')[2]) + ' ' + monthName(c.lastPurchase) : '<span class="muted">بدون خرید</span>'}</td>
        <td class="td-strong ${c.balance ? '' : ''}" style="color:${c.balance ? 'var(--amber)' : 'var(--green)'}">${c.balance ? faMoney(c.balance) : 'تسویه'}</td>
        <td><span class="pill" style="color:${stage.color};background:${stage.color}22">${stage.label}</span></td>
        <td><span class="pill ${stclz}">${stLabel}</span></td>
    </tr>`;
}).join('')}
                </tbody>
            </table>
        </div>
    </div>`;
}
function monthName(d) {
    const mm = ['—', 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
    if (!d) return '';
    const p = new Date(d);
    if (Number.isNaN(p.getTime())) return '';
    return mm[p.getMonth() + 1] || '';
}
function norm(s) {
    return String(s).toLowerCase().replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/ي/g, 'ی').replace(/ك/g, 'ک').replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').replace(/ـ/g, '');
}

/* ---------------- Customer Profile ---------------- */
function customerContacts(c) {
    const stageIdx = CRM_STAGES.findIndex(s => s.key === c.stage);
    return CRM_STAGES.slice(0, Math.max(2, stageIdx + 1)).map((s, i) => ({
        title: s.label, sub: i === stageIdx ? 'مرحله فعلی — ' + userOf(c.owner).name + ' پیگیر است' : 'پیشرفت در چرخه فروش', time: i === stageIdx ? 'امروز' : faNum(i + 1) + ' روز پیش', done: i < stageIdx,
    })).reverse();
}
function pageCustomerProfile() {
    const c = customerOf(STORE.params.id);
    if (!c) return '<div class="empty-state">مشتری یافت نشد</div>';
    const stageIdx = CRM_STAGES.findIndex(s => s.key === c.stage);
    const invs = STORE.invoices.filter(i => i.customer === c.id && i.type === 'فروش');
    const pays = invs.filter(i => i.paid > 0);
    const tasks = STORE.tasks.filter(t => t.customer === c.id);
    const tab = STORE.params.tab || 'info';
    const stage = CRM_STAGES[stageIdx];
    const stLabel = { active: 'فعال', follow: 'در حال پیگیری', lead: 'سرنخ', dormant: 'خاموش' }[c.status];
    const tBody = tab === 'info' ? `
        <div class="grid cols-3">
            <div class="info-item"><div class="il">شماره تماس</div><div class="iv" dir="ltr" style="text-align:right">${c.phone}</div></div>
            <div class="info-item"><div class="il">ایمیل</div><div class="iv">${c.email || '—'}</div></div>
            <div class="info-item"><div class="il">شناسه ملی</div><div class="iv" dir="ltr">${c.regId || '—'}</div></div>
            <div class="info-item"><div class="il">نوع مشتری</div><div class="iv">${c.type}</div></div>
            <div class="info-item"><div class="il">شهر</div><div class="iv">${c.city}</div></div>
            <div class="info-item"><div class="il">مسئول فروش</div><div class="iv">${userOf(c.owner).name}</div></div>
            <div class="info-item"><div class="il">پروژه جاری</div><div class="iv">${c.project || '—'}</div></div>
            <div class="info-item"><div class="il">مانده حساب</div><div class="iv" style="color:${c.balance ? 'var(--amber)':'var(--green)'}">${c.balance ? faMoney(c.balance) : 'تسویه'}</div></div>
            <div class="info-item"><div class="il">اعتبار معاملات</div><div class="iv">${faMoney(c.credit || 0)}</div></div>
        </div>` :
        tab === 'purchases' ? (invs.length ? `<div class="table-wrap"><table class="glass-table"><thead><tr><th>فاکتور</th><th>تاریخ</th><th>شرح کالا</th><th>مبلغ</th><th>پرداخت</th><th>مانده</th><th>وضعیت</th></tr></thead><tbody>${invs.map(i => `<tr><td class="td-strong">${i.id}</td><td>${i.date}</td><td>${i.items}</td><td>${faMoney(i.amount)}</td><td>${faMoney(i.paid)}</td><td>${faMoney(i.amount - i.paid)}</td><td><span class="pill ${pillColor(i.status)}">${i.status === 'paid' ? 'پرداخت شد' : i.status === 'partial' ? 'پرداخت جزئی' : 'پرداخت نشده'}</span></td></tr>`).join('')}</tbody></table></div>` : '<div class="empty-state">سابقه خریدی ثبت نشده است</div>') :
        tab === 'contacts' ? `<div class="timeline">${customerContacts(c).map(x => `<div class="tl-item ${x.done ? 'done' : ''}"><span class="tl-dot"></span><div class="tl-t">${x.title}</div><div class="tl-s">${x.sub}</div><span class="tl-time">${x.time}</span></div>`).join('')}</div>` :
        tab === 'invoices' ? (invs.length ? `<div class="table-wrap"><table class="glass-table"><thead><tr><th>شماره</th><th>تاریخ</th><th>اقلام</th><th>مبلغ</th><th>وضعیت</th></tr></thead><tbody>${invs.map(i => `<tr><td class="td-strong">${i.id}</td><td>${i.date}</td><td>${i.items}</td><td>${faMoney(i.amount)}</td><td><span class="pill ${pillColor(i.status)}">${i.status === 'paid' ? 'پرداخت شد' : i.status === 'partial' ? 'جزئی' : 'نشده'}</span></td></tr>`).join('')}</tbody></table></div>` : '<div class="empty-state">فاکتوری صادر نشده است</div>') :
        tab === 'payments' ? (pays.length ? `<div class="table-wrap"><table class="glass-table"><thead><tr><th>فاکتور</th><th>مبلغ پرداختی</th><th>روش</th><th>وضعیت</th></tr></thead><tbody>${pays.map(i => `<tr><td class="td-strong">${i.id}</td><td>${faMoney(i.paid)}</td><td>چک دریافتی</td><td><span class="pill green">واریز شده</span></td></tr>`).join('')}</tbody></table></div>` : '<div class="empty-state">پرداختی ثبت نشده است</div>') :
        tab === 'tasks' ? (tasks.length ? `<div class="grid cols-2">${tasks.map(t => `<div class="glass-card kb-card" style="border:1px solid var(--stroke)"><div class="kb-card-th"><span class="brand-name">${t.title}</span></div><div class="row wrap"><span class="priority-chip ${prClass(t.priority)}"><span class="bar"></span>${prLabel(t.priority)}</span><span class="pill gray plain">${t.status === 'todo' ? 'جدید' : t.status === 'doing' ? 'در حال انجام' : t.status === 'waiting' ? 'منتظر تایید' : 'انجام شد'}</span></div><div class="kb-meta"><span class="um">${I.clock} ${t.due}</span><span class="um">${I.head} ${userOf(t.assignee).name}</span></div></div>`).join('')}</div>` : '<div class="empty-state">وظیفه مرتبطی وجود ندارد</div>') :
        `<div class="timeline"><div class="tl-item"><span class="tl-dot"></span><div class="tl-t">یادداشت آخرین تماس</div><div class="tl-s">پیشنهاد قیمت میلگرد ۱۴ با ۵٪ تخفیف برای پروژه برج نرگس ارسال شد و مشتری در حال بررسی است.</div><span class="tl-time">۲ روز پیش · علی احمدی</span></div><div class="tl-item"><span class="tl-dot"></span><div class="tl-t">توافق اولیه</div><div class="tl-s">نیاز تقریبی ۶۰ تن میلگرد برای فاز دوم اعلام شد.</div><span class="tl-time">۱ هفته پیش · علی احمدی</span></div><div class="tl-item"><span class="tl-dot"></span><div class="tl-t">معرفی اولیه</div><div class="tl-s">از طریق مراجعه حضوری به دفتر شرکت معرفی شد.</div><span class="tl-time">۱ ماه پیش · علی احمدی</span></div></div>`;
    return `
    <div class="page-head">
        <div><h2>${PAGES.customers.title}</h2><div class="sub">پرونده مشتری</div></div>
        <div class="page-head-actions">
            <button class="btn btn-ghost" onclick="navigateTo('customers')">${I.chev} بازگشت به لیست</button>
            <button class="btn btn-ghost" onclick="showToast('info','تماس با مشتری ثبت شد','تماس اینترنتی برای پیگیری انجام شد')">${I.phone} ثبت تماس</button>
            <button class="btn btn-primary" onclick="openNewInvoiceModal('${c.id}')">${I.doc} فاکتور جدید</button>
        </div>
    </div>
    <div class="glass-card">
        <div class="profile-header">
            <div class="ph-avatar c${(c.id.charCodeAt(1) % 5) + 1}">${c.name.charAt(0)}</div>
            <div>
                <div class="ph-name">${c.name}</div>
                <div class="ph-company">${c.company} · ${c.type}</div>
                <div class="ph-meta">
                    <span>${I.pin} ${c.project || '—'}</span><span>${I.phone} <span dir="ltr">${c.phone}</span></span><span>${I.mail} ${c.email || '—'}</span><span>${I.users} مسئول: ${userOf(c.owner).name}</span>
                </div>
            </div>
            <div class="ph-actions">
                <span class="pill ${stLabel === 'فعال' ? 'green' : 'amber'}">${stLabel}</span>
                <span class="pill" style="color:${stage.color};background:${stage.color}22">${stage.label}</span>
            </div>
        </div>
        <div style="padding:0 24px 10px">
            <div class="stage-track">
                ${CRM_STAGES.map((s, i) => `<div class="stage-node ${i < stageIdx ? 'done' : i === stageIdx ? 'current' : ''}"><div class="sn-dot"></div><div class="sn-label">${s.label}</div></div>`).join('')}
            </div>
            <div class="row" style="justify-content:space-between;margin-top:6px">
                <span class="muted" style="font-size:.74rem">پیشرفت چرخه فروش: <b style="color:var(--cyan-300)">${faNum(stageIdx + 1)}</b> از ${faNum(7)} مرحله</span>
                <button class="btn btn-sm btn-ghost" onclick="nextStage('${c.id}')">${I.up} انتقال به مرحله بعد</button>
            </div>
        </div>
    </div>
    <div class="mt-3">
        <div class="tabs">
            ${[['info', 'اطلاعات مشتری'], ['purchases', 'سوابق خرید'], ['contacts', 'تماس‌ها'], ['invoices', 'فاکتورها'], ['payments', 'پرداخت‌ها'], ['tasks', 'وظایف مرتبط'], ['notes', 'یادداشت‌ها']].map(([k, l]) => `<button class="tab-btn ${tab === k ? 'active' : ''}" onclick="STORE.params.tab='${k}';renderPage()">${l}</button>`).join('')}
        </div>
        <div class="glass-card panel">${tBody}</div>
    </div>`;
}
function nextStage(id) {
    const c = customerOf(id);
    const idx = CRM_STAGES.findIndex(s => s.key === c.stage);
    if (idx >= CRM_STAGES.length - 1) { showToast('info', 'مشتری در آخرین مرحله است', 'این مشتری در وضعیت «مشتری فعال» قرار دارد'); return; }
    const next = CRM_STAGES[idx + 1];
    c.stage = next.key;
    if (next.key === 'active') c.status = 'active';
    logAudit('مشتری «' + c.company + '» به مرحله «' + next.label + '» منتقل شد', 'CRM');
    showToast('success', 'مرحله به‌روزرسانی شد', 'مشتری به «' + next.label + '» منتقل شد');
    renderPage();
}

/* ============================================================
   RENDER: SALES PIPELINE
   ============================================================ */
function pagePipeline() {
    const lanes = PIPELINE_STAGES.map(st => {
        const deals = STORE.deals.filter(d => d.stage === st.key);
        const total = deals.reduce((s, d) => s + d.amount, 0);
        const pm = st.value ?? 0;
        const pct = pm ? Math.min(100, Math.round(total / pm * 100)) : 0;
        return {
            ...st, deals, total, pct,
            cards: deals.map(d => {
                const c = customerOf(d.customer);
                return `<div class="kb-card" draggable="true" data-deal="${d.id}" style="--kc:${st.color}" ondragstart="dragDealStart('${d.id}')" ondragend="dragDealEnd()" onclick="event.stopPropagation()">
                    <div class="kb-card-th"><span class="brand-name">${c ? c.company : ''}</span><span class="pill gray plain" style="margin-inline-start:auto">${d.product.replace(/ .*/, '')}</span></div>
                    <div class="kb-amount">${d.amount ? faMoney(d.amount) : 'بدون مبلغ'}</div>
                    <div class="kb-meta">
                        <span class="um">${I.head} ${userOf(d.seller).name}</span>
                        <span class="um">${I.clock} ${faNum(d.due)}</span>
                    </div>
                </div>`;
            }).join(''),
        };
    });
    const totalValue = STORE.deals.reduce((s, d) => s + d.amount, 0);
    return `
    <div class="page-head">
        <div><h2>${PAGES.pipeline.title}</h2><div class="sub">ارزش کل قیف: <b style="color:var(--cyan-300)">${faMoney(totalValue)}</b> · ${faNum(STORE.deals.length)} فرصت باز</div></div>
        <div class="page-head-actions">
            <button class="btn btn-ghost" onclick="showToast('info','گزارش قیف','گزارش بصورت PDF قابل دانلود است')">${I.file} گزارش قیف</button>
            <button class="btn btn-primary" onclick="openNewDealModal()">${I.plus} فرصت جدید</button>
        </div>
    </div>
    <div class="kanban">
        ${lanes.map(l => `
        <div class="kb-col" data-stage="${l.key}" ondragover="event.preventDefault();this.classList.add('drag-over')" ondragleave="this.classList.remove('drag-over')" ondrop="dropDeal('${l.key}');this.classList.remove('drag-over')">
            <div class="kb-col-head">
                <span class="kb-dot" style="color:${l.color};background:${l.color}"></span>
                <span class="kb-col-title">${l.label}</span>
                <span class="kb-col-count">${faNum(l.deals.length)}</span>
            </div>
            <div style="margin:-2px 8px 12px"><div class="prog"><div style="width:${l.pct}%;background:linear-gradient(90deg,${l.color},${l.color}b0)"></div></div>
            <div style="font-size:.66rem;color:var(--txt-4);margin-top:4px">${faMoney(l.total)} ارزش</div></div>
            <div class="kb-cards">${l.cards || '<div style="font-size:.72rem;color:var(--txt-4);text-align:center;padding:14px">فرصتی وجود ندارد</div>'}</div>
        </div>`).join('')}
    </div>`;
}
function dragDealStart(id) { STORE.dragDeal = id; }
function dragDealEnd() { STORE.dragDeal = null; }
function dropDeal(stage) {
    if (!STORE.dragDeal) return;
    const d = STORE.deals.find(x => x.id === STORE.dragDeal);
    if (d && d.stage !== stage) {
        d.stage = stage;
        const st = PIPELINE_STAGES.find(x => x.key === stage);
        const c = customerOf(d.customer);
        logAudit('فرصت «' + (c ? c.company : '') + '» به مرحله «' + st.label + '» منتقل شد', 'فروش');
        showToast('success', 'فرصت منتقل شد', 'به مرحله «' + st.label + '»');
        renderPage();
    }
}

/* ============================================================
   RENDER: INVENTORY
   ============================================================ */
function pageInventory() {
    const low = STORE.products.filter(p => p.status === 'low');
    const ok = STORE.products.filter(p => p.status !== 'low');
    const cat = STORE.params.cat || '';
    let list = STORE.products;
    if (cat) list = list.filter(p => p.cat === cat);
    return `
    <div class="page-head">
        <div><h2>${PAGES.inventory.title}</h2><div class="sub">${faNum(STORE.products.length)} قلم کالا · ${faNum(STORE.products.reduce((s, p) => s + p.qty * p.weight, 0))} کیلوگرم</div></div>
        <div class="page-head-actions">
            <button class="btn btn-ghost" onclick="openStockModal()">${I.box} ورود / خروج کالا</button>
            <button class="btn btn-primary" onclick="navigateTo('settings', {tab:'products'})">${I.plus} افزودن محصول</button>
        </div>
    </div>
    ${low.length ? `<div class="alert-strip warn">
        <div class="as-icon">${I.warn}</div>
        <div><div class="as-t">${faNum(low.length)} کالا در وضعیت کمبود موجودی قرار دارند</div><div class="as-b">${low.map(p => p.name).join('، ')} — پیشنهاد: ثبت درخواست خرید خودکار</div></div>
        <button class="btn btn-sm btn-warn" onclick="requestPurchaseAuto()">${I.mini} ثبت درخواست خودکار</button>
    </div>` : `<div class="alert-strip"><div class="as-icon" style="background:var(--green-dim);color:var(--green)">${I.check}</div><div class="as-t">وضعیت موجودی سبز است</div></div>`}
    <div class="filter-bar">
        <div class="seg">${[['', 'همه'], ['سیمان', 'سیمان'], ['میلگرد', 'میلگرد'], ['پروفیل', 'پروفیل'], ['ورق', 'ورق']].map(([k, l]) => `<button class="${(cat||'')===k?'active':''}" onclick="STORE.params.cat='${k}';renderPage()">${l}</button>`).join('')}</div>
    </div>
    <div class="grid cols-4">
        ${list.map(p => {
            const pct = Math.min(100, Math.round(p.qty / (p.minStock * 2) * 100));
            const isLow = p.status === 'low';
            return `<div class="glass-card product-card hover">
            ${isLow ? '<div class="low-stock-ribbon">⚠ کمبود موجودی</div>' : ''}
            <div class="pc-top">
                <div class="pc-thumb">${prodIcon(p)}</div>
                <div><div class="pc-name">${p.name}</div><div class="pc-cat">${p.cat} · واحد: ${p.unit}</div></div>
            </div>
            <div class="pc-features">${featBadges(p.features)}</div>
            <div class="pc-specs">
                <div class="pc-spec"><div class="cs">موجودی فعلی</div><div class="cv" style="color:${isLow ? 'var(--amber)' : 'var(--txt)'}">${faNum(p.qty)} ${p.unit}</div></div>
                <div class="pc-spec"><div class="cs">وزن واحد</div><div class="cv">${faNum(p.weight)} کیلوگرم</div></div>
                <div class="pc-spec"><div class="cs">قیمت فروش</div><div class="cv">${faMv(p.sellPrice / 1000)} هر تن</div></div>
                <div class="pc-spec"><div class="cs">بهای تمام‌شده</div><div class="cv">${faMv(p.avgCost / 1000)} هر تن</div></div>
            </div>
            <div class="stock-bar"><div style="width:${pct}%;background:${isLow ? 'var(--amber)' : 'var(--grad-cyan)'}"></div></div>
            <div class="pc-foot">
                <div><span class="pill ${isLow ? 'amber' : 'green'}">${isLow ? 'هشدار' : 'مطلوب'}</span></div>
                <div class="pc-price">${faMoney(p.qty * p.avgCost)} ارزش</div>
            </div>
        </div>`;
        }).join('')}
    </div>
    <div class="muted mt-1" style="font-size:.74rem">نمایش ${faNum(list.length)} قلم کالا</div>`;
}
function requestPurchaseAuto() {
    const fired = triggerAutomations('موجودی کالا زیر حد مجاز شد', 'low');
    logAudit('درخواست خرید خودکار برای کالاهای کم‌موجود ثبت شد', 'انبار');
    showToast('success', 'درخواست خرید ثبت شد', fired.length ? fired.length + ' گردش کار اتوماسیون اجرا شد' : 'اطلاع‌رسانی انجام شد');
    renderPage();
}

/* ============================================================
   RENDER: ACCOUNTING
   ============================================================ */
function pageAccounting() {
    const receivable = STORE.customers.reduce((s, c) => s + c.balance, 0);
    const payable = SUPPLIERS.reduce((s, p) => s + p.balance, 0);
    const income = SERIES.inflow[11] * 1e6;
    const expense = SERIES.outflow[11] * 1e6;
    const profit = income - expense;
    return `
    <div class="page-head">
        <div><h2>${PAGES.accounting.title}</h2><div class="sub">خلاصه مالی · آخرین روز کاری</div></div>
        <div class="page-head-actions">
            <button class="btn btn-ghost" onclick="navigateTo('checks')">${I.bank} مدیریت چک‌ها</button>
            <button class="btn btn-primary" onclick="openJournalModal()">${I.plus} ثبت سند</button>
        </div>
    </div>
    <div class="grid cols-3 mb-3">
        <div class="glass-card fin-stat" style="--fg:rgba(52,211,153,.25)"><div class="fs-label">درآمد ماه جاری</div><div class="fs-value" style="color:var(--green)">${faMoney(income)}</div><div class="fs-sub">${I.up} ۹.۶٪ نسبت به ماه قبل</div></div>
        <div class="glass-card fin-stat" style="--fg:rgba(251,113,133,.22)"><div class="fs-label">هزینه ماه جاری</div><div class="fs-value" style="color:var(--red)">${faMoney(expense)}</div><div class="fs-sub">${I.down} ۴٫۲٪ کاهش نسبت به ماه قبل</div></div>
        <div class="glass-card fin-stat" style="--fg:rgba(0,200,255,.22)"><div class="fs-label">سود خالص</div><div class="fs-value" style="color:var(--cyan-300)">${faMoney(profit)}</div><div class="fs-sub">حاشیه سود ${faNum(Math.round(profit / income * 100))}٪</div></div>
    </div>
    <div class="grid cols-2-1 mb-3">
        <div class="glass-card chart-panel panel">
            <div class="panel-head"><div class="panel-title"><span class="pt-icon">${I.coin}</span> جریان نقد ورودی و خروجی</div></div>
            <div style="height:250px"><canvas id="chCash"></canvas></div>
        </div>
        <div class="glass-card panel">
            <div class="panel-head"><div class="panel-title"><span class="pt-icon">${I.coin}</span> ترکیب هزینه‌ها</div></div>
            <div style="height:170px"><canvas id="chExp"></canvas></div>
            <div class="mt-2 muted" style="font-size:.74rem;text-align:center">بر اساس ماه جاری (میلیون تومان)</div>
        </div>
    </div>
    <div class="grid cols-4">
        <div class="glass-card panel"><div class="li-icon" style="background:var(--green-dim);color:var(--green);margin-bottom:8px">${I.coin}</div><div class="fs-label">مطالبات از مشتریان</div><div class="fs-value" style="font-size:1.25rem;color:var(--amber)">${faMoney(receivable)}</div><div class="fs-sub mt-1">${faNum(STORE.customers.filter(c => c.balance > 0).length)} مشتری بدهکار</div></div>
        <div class="glass-card panel"><div class="li-icon" style="background:var(--violet-dim);color:#C9B8FF;margin-bottom:8px">${I.cart}</div><div class="fs-label">بدهی به تامین‌کنندگان</div><div class="fs-value" style="font-size:1.25rem;color:#C9B8FF">${faMoney(payable)}</div><div class="fs-sub mt-1">${faNum(SUPPLIERS.filter(s => s.balance > 0).length)} تامین‌کننده</div></div>
        <div class="glass-card panel"><div class="li-icon" style="background:var(--amber-dim);color:var(--amber);margin-bottom:8px">${I.bank}</div><div class="fs-label">چک‌های دریافتی</div><div class="fs-value" style="font-size:1.25rem">${faMoney(STORE.checks.filter(c => c.kind === 'received' && c.status === 'pending').reduce((s, c) => s + c.amount, 0))}</div><div class="fs-sub mt-1">${faNum(STORE.checks.filter(c => c.kind === 'received' && c.status === 'pending').length)} چک در دست</div></div>
        <div class="glass-card panel"><div class="li-icon" style="background:var(--red-dim);color:var(--red);margin-bottom:8px">${I.bank}</div><div class="fs-label">چک‌های پرداختی جاری</div><div class="fs-value" style="font-size:1.25rem;color:var(--red)">${faMoney(STORE.checks.filter(c => c.kind === 'paid' && c.status === 'pending').reduce((s, c) => s + c.amount, 0))}</div><div class="fs-sub mt-1">${faNum(STORE.checks.filter(c => c.kind === 'paid' && c.status === 'pending').length)} چک تعهدی</div></div>
    </div>
    ${STORE.journal.length ? `
    <div class="glass-card panel mt-3">
        <div class="panel-head"><div class="panel-title"><span class="pt-icon">${I.doc}</span> ثبت‌های اخیر دفتر روزنامه</div></div>
        ${STORE.journal.slice(0, 8).map(j => `<div class="ledger-item"><div class="li-icon" style="background:${j.type === 'درآمد' ? 'var(--green-dim)' : 'var(--red-dim)'};color:${j.type === 'درآمد' ? 'var(--green)' : 'var(--red)'}">${I.doc}</div><div class="li-main"><div class="li-t">${j.title}</div><div class="li-s">${j.cat} · ${j.date}</div></div><div class="li-val ${j.type === 'هزینه' ? 'out' : ''}">${faMoney(j.amount)}</div></div>`).join('')}
    </div>` : ''}`;
}
function chartsAccounting() {
    mkChart('chCash', {
        type: 'line', data: { labels: MONTHS, datasets: [
            { label: 'ورودی', data: SERIES.inflow, borderColor: '#34D399', backgroundColor: 'rgba(52,211,153,.14)', fill: true, tension: .4, borderWidth: 2.5, pointRadius: 0 },
            { label: 'خروجی', data: SERIES.outflow, borderColor: '#F43F5E', backgroundColor: 'rgba(251,113,133,.1)', fill: true, tension: .4, borderWidth: 2.5, pointRadius: 0 },
        ]},
    });
    mkChart('chExp', {
        type: 'doughnut', data: { labels: EXPENSE_CATS.map(x => x.label), datasets: [{ data: EXPENSE_CATS.map(x => x.value), backgroundColor: EXPENSE_CATS.map(x => x.color), borderColor: '#060D24', borderWidth: 3, hoverOffset: 6 }] },
        Legend: true, Grid: false, Cutout: '68%',
    });
}

/* ============================================================
   RENDER: CHECKS
   ============================================================ */
function pageChecks() {
    const rec = STORE.checks.filter(c => c.kind === 'received');
    const paid = STORE.checks.filter(c => c.kind === 'paid');
    const due3 = c => { const d = (new Date(c.dueDate) - new Date('2026-09-23')) / 86400000; return c.status === 'pending' && d >= 0 && d <= 3; };
    const ckCard = c => `<div class="glass-card check-card hover">
        <div class="row" style="justify-content:space-between">
            <div class="cc-title" style="color:${c.kind === 'received' ? 'var(--green)' : 'var(--red)'}">${I.bank} ${c.id}</div>
            <span class="pill ${c.status === 'passed' ? 'green' : due3(c) ? 'red' : 'amber'}">${c.status === 'passed' ? 'نقد شده' : due3(c) ? 'سررسید نزدیک' : 'در جریان'}</span>
        </div>
        <div class="cc-grid">
            <div><div class="cl">صادرکننده / ذی‌نفع</div><div class="cv">${c.kind === 'received' ? customerOf(c.payer).company : SUPPLIERS.find(s => s.id === c.payer)?.name || ''}</div></div>
            <div><div class="cl">شماره چک</div><div class="cv" dir="ltr">${c.number}</div></div>
            <div><div class="cl">بانک</div><div class="cv">${c.bank}</div></div>
            <div><div class="cl">سررسید</div><div class="cv">${faNum(c.dueDate.split('-')[2])} ${monthName(c.dueDate)} ۱۴۰۵</div></div>
        </div>
        <div class="row" style="justify-content:space-between">
            <div><div class="li-icon" style="background:var(--green-dim);color:var(--green);width:30px;height:30px">${I.coin}</div></div>
            <span class="cc-amount">${faMoney(c.amount)}</span>
        </div>
        ${c.note ? `<div class="muted" style="font-size:.72rem">${c.note}</div>` : ''}
    </div>`;
    return `
    <div class="page-head">
        <div><h2>${PAGES.checks.title}</h2><div class="sub">${faNum(STORE.checks.length)} چک فعال · پیگیری خودکار سررسید ۳ روز قبل</div></div>
        <div class="page-head-actions"><button class="btn btn-primary" onclick="openCheckModal()">${I.plus} ثبت چک</button></div>
    </div>
    <div class="grid cols-2">
        <div>
            <div class="panel-title mb-2" style="color:var(--green)">${I.coin} چک‌های دریافتی (مطالبات)</div>
            <div class="grid">${rec.map(ckCard).join('')}</div>
        </div>
        <div>
            <div class="panel-title mb-2" style="color:var(--red)">${I.bank} چک‌های پرداختی (تعهدات)</div>
            <div class="grid">${paid.map(ckCard).join('')}</div>
        </div>
    </div>`;
}

/* ============================================================
   RENDER: INVOICES
   ============================================================ */
function pageInvoices() {
    const type = STORE.params.type || 'فروش';
    const list = STORE.invoices.filter(i => i.type === type);
    return `
    <div class="page-head">
        <div><h2>${PAGES.invoices.title}</h2><div class="sub">${faNum(STORE.invoices.length)} سند · ${faNum(STORE.invoices.filter(i => i.type === 'فروش').length)} فروش و ${faNum(STORE.invoices.filter(i => i.type === 'خرید').length)} خرید</div></div>
        <div class="page-head-actions">
            <button class="btn btn-ghost" onclick="showToast('info','گزارش','دوره و بازه انتخابی در گزارش منعکس شد')">${I.file} گزارش دوره</button>
            <button class="btn btn-primary" onclick="openNewInvoiceModal()">${I.plus} فاکتور جدید</button>
        </div>
    </div>
    <div class="glass-card panel">
        <div class="filter-bar">
            <div class="seg">${[['فروش', 'فاکتور فروش'], ['خرید', 'فاکتور خرید']].map(([k, l]) => `<button class="${type===k?'active':''}" onclick="STORE.params.type='${k}';renderPage()">${l}</button>`).join('')}</div>
            <div class="input-glass" style="display:flex;align-items:center;gap:8px;min-width:240px">${I.search}<input class="input-glass" style="border:none;background:none;width:100%" placeholder="جستجوی شماره فاکتور..." oninput="STORE.params.q=this.value;renderPage()"></div>
        </div>
        <div class="table-wrap"><table class="glass-table">
            <thead><tr><th>شماره</th><th>طرف حساب</th><th>تاریخ</th><th>شرح اقلام</th><th>مبلغ</th><th>پرداختی</th><th>مانده</th><th>وضعیت</th></tr></thead>
            <tbody>${list.filter(i => !STORE.params.q || norm(i.id).includes(norm(STORE.params.q))).map(i => `
                <tr onclick="showToast('info','فاکتور ' + '${i.id}' + ' باز شد','نمایش جزئیات سند')">
                    <td class="td-strong">${i.id}</td>
                    <td>${cmpName(i.customer)}</td><td>${i.date}</td><td>${i.items}</td>
                    <td class="td-strong">${faMoney(i.amount)}</td><td>${faMoney(i.paid)}</td>
                    <td style="color:${i.amount - i.paid ? 'var(--amber)' : 'var(--green)'}">${faMoney(i.amount - i.paid)}</td>
                    <td><span class="pill ${pillColor(i.status)}">${i.status === 'paid' ? 'تسویه شد' : i.status === 'partial' ? 'پرداخت جزئی' : 'پرداخت نشده'}</span></td>
                </tr>`).join('')}</tbody>
        </table></div>
    </div>`;
}

/* ============================================================
   RENDER: PURCHASE
   ============================================================ */
function pagePurchase() {
    const purch = STORE.invoices.filter(i => i.type === 'خرید');
    return `
    <div class="page-head">
        <div><h2>${PAGES.purchase.title}</h2><div class="sub">${faNum(SUPPLIERS.length)} تامین‌کننده همکار · مدیریت سفارش و تامین کالا</div></div>
        <div class="page-head-actions">
            <button class="btn btn-ghost" onclick="showToast('info','سفارش','استعلام جدید ثبت شد')">${I.note} استعلام قیمت</button>
            <button class="btn btn-primary" onclick="showToast('success','سفارش خرید ثبت شد','فرآیند تایید مدیر آغاز شد')">${I.plus} سفارش خرید</button>
        </div>
    </div>
    <div class="grid cols-2-1 mb-3">
        <div class="glass-card panel">
            <div class="panel-head"><div class="panel-title"><span class="pt-icon">${I.cart}</span> تامین‌کنندگان</div></div>
            <div class="table-wrap"><table class="glass-table">
                <thead><tr><th>تامین‌کننده</th><th>محصولات</th><th>زمان تحویل</th><th>مانده حساب</th><th></th></tr></thead>
                <tbody>${SUPPLIERS.map(s => `<tr>
                    <td><div class="customer-row"><div class="customer-avatar c3">${s.name.charAt(0)}</div><div><div class="td-strong">${s.name}</div><div class="muted" style="font-size:.7rem">${s.phone}</div></div></div></td>
                    <td>${s.product}</td><td><span class="pill cyan plain">${s.delivery}</span></td>
                    <td style="color:${s.balance ? 'var(--amber)' : 'var(--green)'}">${s.balance ? faMoney(s.balance) : 'تسویه'}</td>
                    <td><button class="btn btn-sm btn-outline" onclick="showToast('info','سفارش به ' + '${s.name}' + '','پیش‌فاکتور ارسال شد')">سفارش</button></td>
                </tr>`).join('')}</tbody>
            </table></div>
        </div>
        <div class="glass-card panel">
            <div class="panel-head"><div class="panel-title"><span class="pt-icon">${I.doc}</span> دریافت‌های اخیر</div></div>
            ${purch.map(i => `<div class="ledger-item"><div class="li-icon" style="background:var(--violet-dim);color:#C9B8FF">${I.box}</div><div class="li-main"><div class="li-t">${i.id} · ${cmpName(i.customer)}</div><div class="li-s">${i.items}</div></div><div class="li-val out">${faMoney(i.amount)}</div></div>`).join('')}
        </div>
    </div>`;
}

/* ============================================================
   RENDER: TASKS
   ============================================================ */
function taskCard(t) {
    const st = { todo: ['جدید', 'cyan'], doing: ['در حال انجام', 'amber'], waiting: ['منتظر تایید', 'violet'], done: ['انجام شده', 'green'] }[t.status];
    const cust = t.customer ? (customerOf(t.customer)?.company || '') : '';
    return `<div class="kb-card" draggable="true" data-task="${t.id}" ondragstart="dragTaskStart('${t.id}')" ondragend="dragDealEnd()" style="--kc:${st[1] === 'cyan' ? '#00C8FF' : st[1] === 'amber' ? '#FBBF24' : st[1] === 'violet' ? '#8B5CF6' : '#34D399'}">
<div class="kb-card-th"><span class="kb-ic">${taskIcon(t)}</span><span class="brand-name">${t.title}</span></div>
        ${t.descr ? `<div class="muted" style="font-size:.72rem">${t.descr}</div>` : ''}
        <div class="task-tags">${t.tags.map(x => `<span class="tag-chip">${x}</span>`).join('')}${cust ? `<span class="tag-chip">${cust}</span>` : ''}</div>
        <div class="row wrap" style="margin-top:10px"><span class="priority-chip ${prClass(t.priority)}"><span class="bar"></span>${prLabel(t.priority)}</span><span class="pill ${st[1]}">${st[0]}</span></div>
        <div class="kb-meta" style="justify-content:space-between">
            <div class="avatar-stack"><div class="avatar-sm" title="${userOf(t.assignee).name}">${userOf(t.assignee).initials}</div></div>
            <span class="um">${I.clock} ${t.due}</span>
            <span class="um">${I.file}</span>
        </div>
    </div>`;
}
function pagesTasks() {
    const view = STORE.params.view || 'kanban';
    const tState = ['todo', 'doing', 'waiting', 'done'];
    const tL = { todo: 'جدید', doing: 'در حال انجام', waiting: 'منتظر تایید', done: 'انجام شده' };
    const tC = { todo: '#00C8FF', doing: '#FBBF24', waiting: '#8B5CF6', done: '#34D399' };
    const body = view === 'kanban' ? `<div class="kanban">
        ${tState.map(s => `<div class="kb-col" data-stage="${s}" ondragover="event.preventDefault();this.classList.add('drag-over')" ondragleave="this.classList.remove('drag-over')" ondrop="dropTask('${s}');this.classList.remove('drag-over')">
            <div class="kb-col-head"><span class="kb-dot" style="color:${tC[s]};background:${tC[s]}"></span><span class="kb-col-title">${tL[s]}</span><span class="kb-col-count">${faNum(STORE.tasks.filter(t => t.status === s).length)}</span></div>
            <div class="kb-cards">${STORE.tasks.filter(t => t.status === s).map(taskCard).join('') || '<div style="font-size:.72rem;color:var(--txt-4);text-align:center;padding:14px">وظیفه‌ای نیست</div>'}</div>
        </div>`).join('')}
    </div>` : view === 'calendar' ? `<div class="glass-card panel"><div class="panel-head"><div class="panel-title"><span class="pt-icon">${I.calendar}</span> نقشه وظایف — مهر ۱۴۰۵</div><span class="panel-more">ویرایشی مختصر</span></div><div style="height:320px;display:grid;place-items:center"><div style="text-align:center" class="muted">${I.calendar}<div class="mt-1" style="font-size:.86rem;font-weight:700">نمای تقویمی وظایف</div><div style="font-size:.74rem">${faNum(STORE.tasks.length)} وظیفه فعال با سررسید تعریف‌شده</div><div class="grid cols-4 mt-2" style="max-width:520px;margin-left:auto;margin-right:auto">${['todo','doing','waiting','done'].map(s => `<div class="glass-card" style="padding:12px"><div class="fs-label">${tL[s]}</div><div class="fs-value">${faNum(STORE.tasks.filter(t=>t.status===s).length)}</div></div>`).join('')}</div></div></div></div>` : `
        <div class="road">
            ${STORE.tasks.slice().sort((a, b) => a.due.localeCompare(b.due)).map(t => `<div class="road-item">
                <div class="road-dot">${taskIcon(t)}</div>
                <div class="road-card">
                    <div class="row" style="justify-content:space-between;flex-wrap:wrap;gap:8px">
                        <div><div class="road-date">${I.clock} سررسید: ${faNum(t.due.split('-')[2])} ${monthName(t.due)}</div><div style="font-weight:800;margin-top:5px">${t.title}</div></div>
                        <div class="row"><span class="priority-chip ${prClass(t.priority)}"><span class="bar"></span>${prLabel(t.priority)}</span><span class="pill ${t.status==='done'?'green':t.status==='doing'?'amber':t.status==='waiting'?'violet':'cyan'}">${tL[t.status]}</span></div>
                    </div>
                    <div class="muted mt-1" style="font-size:.78rem">${t.descr || ''}</div>
                    <div class="kb-meta"><span class="um">${I.head} ${userOf(t.assignee).name}</span>${t.ref ? `<span class="um">${I.tag} ${t.ref}</span>` : ''}</div>
                </div>
            </div>`).join('')}
        </div>`;
    return `
    <div class="page-head">
        <div><h2>${PAGES.tasks.title}</h2><div class="sub">${faNum(STORE.tasks.length)} وظیفه · ${faNum(STORE.tasks.filter(t => t.status === 'doing').length)} در حال انجام</div></div>
        <div class="page-head-actions">
            <div class="seg">${[['kanban', 'کانبان'], ['calendar', 'تقویم وظایف'], ['timeline', 'تایم‌لاین']].map(([k, l]) => `<button class="${view===k?'active':''}" onclick="STORE.params.view='${k}';renderPage()">${l}</button>`).join('')}</div>
            <button class="btn btn-primary" onclick="openNewTaskModal()">${I.plus} وظیفه جدید</button>
        </div>
    </div>
    ${body}`;
}
function dragTaskStart(id) { STORE.dragTask = id; }
function dropTask(stage) {
    if (!STORE.dragTask) return;
    const t = STORE.tasks.find(x => x.id === STORE.dragTask);
    if (t && t.status !== stage) {
        t.status = stage;
        const names = { todo: 'جدید', doing: 'در حال انجام', waiting: 'منتظر تایید', done: 'انجام شده' };
        logAudit('وظیفه «' + t.title + '» به وضعیت «' + names[stage] + '» تغییر کرد', 'وظایف');
        showToast('success', 'وضعیت وظیفه تغییر کرد', names[stage]);
        renderPage();
    }
}

/* ============================================================
   RENDER: CALENDAR (Meetings)
   ============================================================ */
function monthGrid(month) {
    const evs = MEETINGS.filter(e => e.month === month);
    const offset = 3; // مهر از چهارشنبه شروع می‌شود
    const days = 30;
    const today = month === 'مهر' ? 23 : 0;
    const currentDay = new Date().getDate() + (month === 'مهر' ? 0 : 0);
    let cells = [];
    for (let i = 0; i < offset; i++) cells.push({ empty: true });
    for (let d = 1; d <= days; d++) cells.push({ day: d });
    const dow = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];
    return `
    <div class="calendar-head" style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
        <div class="row"><button class="icon-btn" onclick="STORE.calMonth='مهر';renderPage()">${I.chev}</button><span style="font-weight:900;font-size:1.15rem">${month} ۱۴۰۵</span><button class="icon-btn" style="transform:rotate(180deg)" onclick="STORE.calMonth='آبان';renderPage()">${I.chev}</button></div>
        <button class="btn btn-primary btn-sm" onclick="openMeetingModal()">${I.plus} جلسه جدید</button>
    </div>
    <div class="cal-grid">
        ${dow.map(d => `<div class="cal-dow">${d}</div>`).join('')}
        ${cells.map(c => {
            if (c.empty) return '<div class="cal-cell empty"></div>';
            const dayEvs = evs.filter(e => e.day === c.day);
            const isToday = month === 'مهر' && c.day === 23;
            return `<div class="cal-cell ${isToday ? 'today' : ''}">
                <span class="cc-num">${faNum(c.day)}</span>
                ${dayEvs.slice(0, 2).map(e => `<div class="cal-event" style="--ce:${e.type === 'مشتری' ? '#00C8FF' : e.type === 'فروش' ? '#8B5CF6' : e.type === 'انبار' ? '#FBBF24' : e.type === 'مالی' ? '#34D399' : '#F43F5E'}" title="${e.title}">${e.time} ${e.title}</div>`).join('')}
                ${dayEvs.length > 2 ? `<span class="cc-more">+${faNum(dayEvs.length - 2)} دیگر</span>` : ''}
            </div>`;
        }).join('')}
    </div>`;
}
function pageCalendar() {
    const month = STORE.calMonth || 'مهر';
    return `
    <div class="page-head">
        <div><h2>${PAGES.calendar.title}</h2><div class="sub">جلسات، بازدیدها و رویدادهای هماهنگ‌شده تیم</div></div>
    </div>
    <div class="glass-card panel">${monthGrid(month)}</div>
    <div class="grid cols-2 mt-3">
        <div class="glass-card panel">
            <div class="panel-head"><div class="panel-title"><span class="pt-icon">${I.clock}</span> جلسات پیش‌رو</div></div>
            ${MEETINGS.filter(e => e.month === month).slice(0, 5).map(e => `<div class="ledger-item"><div class="li-icon" style="background:rgba(0,200,255,.12);color:var(--cyan-300)">${I.calendar}</div><div class="li-main"><div class="li-t">${e.title}</div><div class="li-s">${faNum(e.day)} ${e.month} · ${e.time}</div></div><span class="tag-chip">${e.type}</span></div>`).join('')}
        </div>
        <div class="glass-card panel">
            <div class="panel-head"><div class="panel-title"><span class="pt-icon">${I.users}</span> دسترس‌پذیری تیم فروش</div></div>
            ${USERS.map(u => `<div class="row" style="padding:9px 4px;border-bottom:1px solid rgba(255,255,255,.05)"><div class="avatar-sm">${u.initials}</div><span style="font-weight:700;font-size:.84rem;flex:1">${u.name}</span><span class="muted" style="font-size:.72rem">${ROLES[u.role].label}</span><span class="pill green">آزاد</span></div>`).join('')}
        </div>
    </div>`;
}

/* ============================================================
   RENDER: REPORTS
   ============================================================ */
function pageReports() {
    const ranked = STORE.customers.filter(c => c.balance > 0).slice().sort((a, b) => b.balance - a.balance).slice(0, 5);
    return `
    <div class="page-head">
        <div><h2>${PAGES.reports.title}</h2><div class="sub">مرکز تحلیل و گزارش‌گیری سازمانی</div></div>
        <div class="page-head-actions"><button class="btn btn-primary" onclick="showToast('info','گزارش دوره','گزارش جامع دوره جاری ساخته و دانلود شد')">${I.file} خروجی گزارش جامع</button></div>
    </div>
    <div class="grid cols-4 mb-3">
        ${[
            ['فروش', I.chart, 'تحلیل فروش ماهانه، تفکیک کالا و مشتری', 'var(--green-dim)', '#34D399'],
            ['مشتریان', I.users, 'رشد، ریزش و ارزش مشتریان', 'var(--cyan-dim)', '#00C8FF'],
            ['موجودی', I.box, 'گردش کالا و هشدار موجودی', 'var(--amber-dim)', '#FBBF24'],
            ['عملکرد کارکنان', I.head, 'فروش، تماس و تکمیل وظایف', 'var(--violet-dim)', '#8B5CF6'],
            ['مالی', I.coin, 'صورت سود و زیان، جریان نقد', 'var(--red-dim)', '#F43F5E'],
            ['خرید و تامین', I.cart, 'هزینه تامین و انحراف قیمت', 'var(--cyan-dim)', '#0B7BFF'],
            ['چک‌ها', I.bank, 'وضعیت سررسید و نقدشوندگی', 'var(--violet-dim)', '#C084FC'],
            ['گزارش مدیریتی', I.spark, 'خلاصه یک‌صفحه‌ای برای مدیران', 'var(--green-dim)', '#34D399'],
        ].map(([t, ic, s, bg, fg]) => `<div class="glass-card report-card hover">
            <div class="rep-icon" style="background:${bg};color:${fg}">${ic}</div>
            <div><div class="rep-title">گزارش ${t}</div><div class="rep-sub">${s}</div></div>
            <div class="rep-meta"><span class="pill gray plain">امروز</span><span class="btn btn-sm btn-outline" onclick="viewReport('${t}')">${I.mini} مشاهده</span></div>
        </div>`).join('')}
    </div>
    <div class="grid cols-2-1">
        <div class="glass-card chart-panel panel">
            <div class="panel-head"><div class="panel-title"><span class="pt-icon">${I.chart}</span> مقایسه فروش و خرید ماهانه</div></div>
            <div style="height:270px"><canvas id="chRep"></canvas></div>
        </div>
        <div class="glass-card panel">
            <div class="panel-head"><div class="panel-title"><span class="pt-icon">${I.coin}</span> مشتریان دارای مطالبات بالا</div></div>
            ${ranked.map((c, i) => `<div class="rank-row"><span class="rank-num">${faNum(i + 1)}</span><div class="rank-main"><div class="rank-t">${c.company}</div><div class="rank-s">${c.project || c.city}</div></div><div class="rank-val">${faMoney(c.balance)}</div></div>`).join('')}
            <div class="mt-2"><button class="btn btn-sm btn-ghost" style="width:100%" onclick="navigateTo('customers')">مشاهده مشتریان ←</button></div>
        </div>
    </div>
    <div class="glass-card panel mt-3">
        <div class="panel-head"><div class="panel-title"><span class="pt-icon">${I.head}</span> عملکرد کارکنان فروش (ماه جاری)</div></div>
        <div class="table-wrap"><table class="glass-table">
            <thead><tr><th>کارمند</th><th>نقش</th><th>فروش موفق</th><th>ارزش فروش</th><th>تماس‌ها</th><th>وظایف تکمیل</th><th>راندمان</th></tr></thead>
            <tbody>${EMP_PERF.map(e => {
                const u = userOf(e.user);
                const eff = Math.round(Math.min(100, (e.calls / 50) * 70 + (e.sales / 4) * 30));
                return `<tr><td><div class="customer-row"><div class="avatar-sm">${u.initials}</div><span class="td-strong">${u.name}</span></div></td>
                <td><span class="pill gray plain">${ROLES[u.role].label}</span></td><td>${faNum(e.sales)}</td><td class="td-strong">${faMoney(e.value * 1e6)}</td><td>${faNum(e.calls)}</td><td>${faNum(e.tasks)}</td>
                <td style="min-width:120px"><div class="row"><div class="prog grow-1"><div style="width:${eff}%;background:linear-gradient(90deg,#006BFF,#00C8FF)"></div></div><span style="font-size:.72rem;font-weight:800">${faNum(eff)}٪</span></div></td></tr>`;
            }).join('')}</tbody>
        </table></div>
    </div>`;
}
function chartsReports() {
    mkChart('chRep', {
        type: 'bar', data: { labels: MONTHS, datasets: [
            { label: 'فروش', data: SERIES.sales, backgroundColor: 'rgba(0,200,255,.55)', borderRadius: 6, barPercentage: .55 },
            { label: 'خرید', data: SERIES.purchases, backgroundColor: 'rgba(139,92,246,.5)', borderRadius: 6, barPercentage: .55 },
        ]},
    });
}
function viewReport(key) {
    const sales = STORE.invoices.filter(i => i.type === 'فروش');
    const buys = STORE.invoices.filter(i => i.type === 'خرید');
    const sum = a => a.reduce((s, x) => s + (x.amount || 0), 0);
    const paidSum = a => a.reduce((s, x) => s + (x.paid || 0), 0);
    const receivable = STORE.customers.reduce((s, c) => s + (c.balance || 0), 0);
    const payable = SUPPLIERS.reduce((s, p) => s + (p.balance || 0), 0);
    const low = STORE.products.filter(p => p.status === 'low');
    const recv = STORE.checks.filter(c => c.kind === 'received');
    const paid = STORE.checks.filter(c => c.kind === 'paid');
    const S = (l, v, x, c) => `<div class="rep-stat glass-card"><div class="fs-label">${l}</div><div class="fs-value" style="color:${c || 'var(--txt)'}">${v}</div>${x ? `<div class="fs-sub">${x}</div>` : ''}</div>`;
    const item = (ic, bg, t1, t2, val) => `<div class="ledger-item"><div class="li-icon" style="background:${bg}">${ic}</div><div class="li-main"><div class="li-t">${t1}</div><div class="li-s">${t2}</div></div><div class="li-val">${val}</div></div>`;
    let ic = I.chart, stats = '', list = '';
    if (key === 'فروش') {
        stats = S('تعداد فاکتور', faNum(sales.length), 'فروش') + S('ارزش فروش', faMoney(sum(sales)), 'جمع مبالغ') + S('دریافتی', faMoney(paidSum(sales)), 'پرداخت‌شده') + S('مانده', faMoney(sum(sales) - paidSum(sales)), 'طبق فاکتورها', 'var(--amber)');
        list = sales.slice(0, 6).map(i => item(I.doc, 'rgba(0,200,255,.12)', i.id + ' · ' + cmpName(i.customer), i.date, faMoney(i.amount - (i.paid || 0)))).join('');
    } else if (key === 'مشتریان') {
        stats = S('کل مشتریان', faNum(STORE.customers.length), 'پایگاه داده') + S('بدهکار', faNum(STORE.customers.filter(c => c.balance > 0).length), 'تاکنون') + S('جمع مطالبات', faMoney(receivable), 'مانده', 'var(--amber)') + S('فرصت مذاکره', faNum(STORE.deals.filter(d => d.stage === 'negotiate').length), 'در حال پیگیری');
        list = STORE.customers.filter(c => c.balance > 0).slice(0, 6).map(c => item(I.users, 'rgba(139,92,246,.15)', c.company, c.city || '—', faMoney(c.balance))).join('');
    } else if (key === 'موجودی') {
        stats = S('قلم کالا', faNum(STORE.products.length), 'کاتالوگ') + S('کمبود موجودی', faNum(low.length), low.length ? 'نیازمند تامین' : 'وضعیت سالم', low.length ? 'var(--amber)' : 'var(--green)') + S('ارزش موجودی', faMoney(STORE.products.reduce((s, p) => s + p.qty * p.avgCost, 0)), 'به بهای تمام‌شده') + S('موجودی فیزیکی', faNum(STORE.products.reduce((s, p) => s + p.qty, 0)), 'واحد');
        list = low.slice(0, 6).map(p => item(I.box, 'rgba(251,191,36,.15)', p.name, 'حد مجاز: ' + faNum(p.minStock) + ' ' + p.unit, faNum(p.qty) + ' ' + p.unit)).join('');
    } else if (key === 'عملکرد کارکنان') {
        stats = S('کارمند', faNum(EMP_PERF.length), 'نفر') + S('فروش موفق', faNum(EMP_PERF.reduce((s, e) => s + e.sales, 0)), 'قرارداد') + S('ارزش فروش', faMoney(EMP_PERF.reduce((s, e) => s + e.value, 0) * 1e6), 'مجموع') + S('تماس‌ها', faNum(EMP_PERF.reduce((s, e) => s + e.calls, 0)), 'مکالمه');
        list = EMP_PERF.slice(0, 6).map(e => item(I.head, 'rgba(139,92,246,.15)', userOf(e.user).name, ROLES[userOf(e.user).role].label, faNum(e.sales) + ' فروش')).join('');
    } else if (key === 'مالی') {
        stats = S('مطالبات', faMoney(receivable), 'از مشتریان', 'var(--amber)') + S('بدهی‌ها', faMoney(payable), 'به تامین‌کنندگان', 'var(--red)') + S('چک دریافتی در دست', faMoney(sum(recv.filter(c => c.status === 'pending'))), faNum(recv.filter(c => c.status === 'pending').length) + ' چک') + S('چک پرداختی جاری', faMoney(sum(paid.filter(c => c.status === 'pending'))), faNum(paid.filter(c => c.status === 'pending').length) + ' چک', 'var(--red)');
        list = STORE.invoices.slice(0, 6).map(i => item(I.coin, 'rgba(52,211,153,.15)', i.id + ' · ' + cmpName(i.customer), i.date, faMoney(i.amount))).join('');
    } else if (key === 'خرید و تامین') {
        stats = S('تامین‌کننده', faNum(SUPPLIERS.length), 'همکار') + S('فاکتور خرید', faNum(buys.length), 'سند') + S('ارزش خرید', faMoney(sum(buys)), 'جمع') + S('بدهی تامین', faMoney(payable), 'مانده', 'var(--red)');
        list = buys.slice(0, 6).map(i => item(I.cart, 'rgba(0,123,255,.15)', i.id + ' · ' + cmpName(i.customer), i.date, faMoney(i.amount))).join('');
    } else if (key === 'چک‌ها') {
        stats = S('دریافتی', faNum(recv.length), 'چک', 'var(--green)') + S('ارزش دریافتی', faMoney(sum(recv)), 'مجموع در دست') + S('پرداختی', faNum(paid.length), 'چک', 'var(--red)') + S('ارزش پرداختی', faMoney(sum(paid)), 'تعهدات', 'var(--red)');
        list = recv.concat(paid).slice(0, 6).map(c => item(I.bank, c.kind === 'received' ? 'rgba(52,211,153,.15)' : 'rgba(251,113,133,.15)', c.id + ' · ' + c.bank, 'سررسید ' + faNum(c.dueDate.split('-')[2]) + ' ' + monthName(c.dueDate), faMoney(c.amount))).join('');
    } else {
        ic = I.spark;
        stats = S('درآمد دوره', faMoney(SERIES.inflow[11] * 1e6), 'ماه جاری', 'var(--green)') + S('هزینه دوره', faMoney(SERIES.outflow[11] * 1e6), 'ماه جاری', 'var(--red)') + S('وظایف تکمیل', faNum(STORE.tasks.filter(t => t.status === 'done').length), 'از ' + faNum(STORE.tasks.length)) + S('مطالبات', faMoney(receivable), 'مانده مشتریان', 'var(--amber)');
        list = STORE.audit.slice(0, 6).map(a => item(I.clock, 'rgba(0,200,255,.12)', a.action, a.module + ' · ' + a.date, a.user)).join('');
    }
    openModal(`
        <div class="modal-head"><h3>${ic} گزارش ${key}</h3><button class="modal-close" onclick="closeModal()">${I.x}</button></div>
        <div class="modal-body">
            <div class="grid" style="grid-template-columns:1fr 1fr;gap:12px">${stats}</div>
            <div class="mt-2" style="font-size:.76rem;font-weight:800;color:var(--txt-2);margin-bottom:6px">اخیرترین رکوردها</div>
            ${list || '<div class="muted" style="font-size:.76rem">هنوز رکوردی ثبت نشده است.</div>'}
        </div>
        <div class="modal-foot"><button class="btn btn-ghost" onclick="closeModal()">بستن</button></div>`);
}

/* ============================================================
   RENDER: AUTOMATION
   ============================================================ */
function wfNode(n) {
    return `<div class="auto-node">
        <div class="an-icon" style="background:${n.color}55;border:1px solid ${n.color}88">${I[n.icon]}</div>
        <div><span class="an-tag" style="color:${n.color}">${n.label}</span><div class="an-text">${n.text}</div></div>
    </div>`;
}
function pageAutomation() {
    return `
    <div class="page-head">
        <div><h2>${PAGES.automation.title}</h2><div class="sub">${faNum(STORE.workflows.filter(w => w.enabled).length)} گردش کار فعال · اجرای خودکار بدون دخالت کاربر</div></div>
        <div class="page-head-actions">
            <button class="btn btn-ghost" onclick="showToast('info','الگوها','کتابخانه گردش‌کارهای آماده باز شد')">${I.mini} قالب‌های آماده</button>
            <button class="btn btn-primary" onclick="openWorkflowModal()">${I.plus} گردش کار جدید</button>
        </div>
    </div>
    <div class="grid cols-2">
        ${STORE.workflows.map((wf, idx) => `
        <div class="glass-card workflow-card">
            <div class="wf-head">
                <div class="pc-thumb" style="width:44px;height:44px;border-radius:13px;background:var(--grad-brand-soft)">${I.spark}</div>
                <div><div class="wf-name">${wf.name}</div><div class="wf-trigger">${I.clock} رویداد: ${wf.trigger}</div></div>
                <div class="wf-status"><label class="switch"><input type="checkbox" ${wf.enabled ? 'checked' : ''} onchange="toggleWf('${wf.id}', this.checked)"><span class="slider"></span></label></div>
            </div>
            <div class="workflow-canvas">
                ${wf.nodes.map(n => wfNode(n)).join('<div class="an-connector"></div>')}
            </div>
            <div class="wf-log" id="wfLog${wf.id}">
                <div class="wf-run-line" style="color:var(--cyan-300)">● گردش کار آماده اجراست — رویداد «${wf.trigger}» فعال شد.</div>
            </div>
            <div class="row mt-2" style="justify-content:space-between">
                <button class="btn btn-sm btn-outline" onclick="showToast('info','ویرایش گردش کار','ویرایشگر نود باز شد')">${I.gear} ویرایش</button>
                <button class="btn btn-sm btn-primary" onclick="runWf('${wf.id}', ${idx})">${I.play ? I.play : '<svg viewBox="0 0 24 24" fill="currentColor"><polygon points="6 3 20 12 6 21 6 3"/></svg>'} اجرای آزمایشی</button>
            </div>
        </div>`).join('')}
    </div>`;
}
function runWf(id, idx) {
    const wf = STORE.workflows.find(w => w.id === id);
    if (!wf) return;
    const log = document.getElementById('wfLog' + id);
    log.innerHTML = `<div class="wf-run-line r-run">◉ شروع اجرا — رویداد: ${wf.trigger}</div>`;
    let i = 0;
    const results = runWorkflow(wf);
    const interval = setInterval(() => {
        const r = results[i];
        if (!r) {
            clearInterval(interval);
            const line = document.createElement('div');
            line.className = 'wf-run-line r-ok';
            line.innerHTML = '✔ گردش کار با موفقیت انجام شد — ' + faNum(results.length) + ' اقدام';
            log.appendChild(line);
            showToast('success', 'اتوماسیون اجرا شد', '«' + wf.name + '» — ' + faNum(results.length) + ' اقدام انجام شد');
            return;
        }
        const line = document.createElement('div');
        line.className = 'wf-run-line' + (r.ok ? ' r-ok' : ' r-run');
        line.innerHTML = (r.ok ? '✔ ' : '◌ ') + r.text;
        log.appendChild(line);
        i++;
    }, 420);
    setTimeout(() => { STORE.page = 'automation'; }, 50);
}
function toggleWf(id, on) {
    const wf = STORE.workflows.find(w => w.id === id);
    if (wf) { wf.enabled = on; logAudit('گردش کار «' + wf.name + '» ' + (on ? 'فعال' : 'غیرفعال') + ' شد', 'اتوماسیون'); showToast(on ? 'success' : 'info', on ? 'گردش کار فعال شد' : 'گردش کار متوقف شد', wf.name); }
}

/* ============================================================
   RENDER: AI ASSISTANT
   ============================================================ */
function aiStats(items) {
    return `<div class="ai-stats">${items.map(x => `<div class="ai-stat"><div class="as-v">${x.v}</div><div class="as-l">${x.l}</div></div>`).join('')}</div>`;
}
function aiMessage(role, html) {
    const u = userOf(STORE.user.id);
    return `<div class="ai-msg ${role === 'user' ? 'user' : 'ai'}">
        <div class="msg-avatar" style="${role === 'user' ? 'order:2;background:linear-gradient(135deg,#7C6CFF,#F59E0B)' : ''}">${role === 'user' ? u.initials : I.robot}</div>
        <div class="msg-bubble">${html}</div>
    </div>`;
}
function aiWelcome() {
    STORE.chat = [];
    const el = document.getElementById('chatBody');
    el.innerHTML = aiMessage('ai', `
        <p>سلام <b>${userOf(STORE.user.id).name}</b> عزیز 👋<br>من <b>دستیار هوشمند بنا‌پی</b> هستم و به داده‌های زنده سازمان متصل‌ام.</p>
        <h4>می‌توانید از من بپرسید:</h4>
        <ul>
            <li>فروش این ماه چقدر بوده و کدام مشتری بهتر خریده؟</li>
            <li>کدام کالا در خطر اتمام موجودی است؟</li>
            <li>بیشترین هزینه این ماه چه بوده؟</li>
            <li>کدام کارها عقب افتاده است؟</li>
        </ul>`);
    renderSuggestions();
}
function renderSuggestions() {
    const chips = ['فروش این ماه را تحلیل کن', 'کدام مشتری‌ها خرید نکرده‌اند؟', 'کدام کالا در خطر اتمام است؟', 'بیشترین هزینه این ماه چه بوده؟', 'کارهای عقب افتاده چیست؟'];
    document.getElementById('sugChips').innerHTML = chips.map(c => `<button class="sug-chip" onclick="askAI('${c}')">${c}</button>`).join('');
}
function pageAI() {
    STORE.calMonth = STORE.calMonth;
    return `
    <div class="page-head">
        <div><h2>${PAGES.ai.title}</h2><div class="sub">تحلیل کسب‌وکار با داده‌های زنده سازمان</div></div>
    </div>
    <div class="ai-layout">
        <div class="glass-card chat-panel">
            <div class="chat-body" id="chatBody"></div>
            <div class="suggestions" id="sugChips"></div>
            <div class="chat-input-bar">
                <input id="aiInput" placeholder="مثلاً: وضعیت موجودی انبار را تحلیل کن..." onkeydown="if(event.key==='Enter')askAI(this.value)">
                <button class="btn btn-primary btn-icon" onclick="askAI(document.getElementById('aiInput').value)">${I.send}</button>
            </div>
        </div>
        <div class="glass-card ai-quick" style="height:fit-content">
            <div class="aq-title">${I.spark} توانمندی‌های دستیار</div>
            <div class="row"><span class="pill cyan">${I.chart} تحلیل فروش</span></div>
            <div class="row"><span class="pill green">${I.users} بینش مشتریان</span></div>
            <div class="row"><span class="pill amber">${I.box} پیش‌بینی موجودی</span></div>
            <div class="row"><span class="pill violet">${I.coin} خلاصه مالی</span></div>
            <div class="row"><span class="pill red">${I.warn} هشدارهای عملیاتی</span></div>
            <div style="border-top:1px solid var(--stroke);padding-top:14px;margin-top:8px">
                <div class="aq-title" style="font-size:.86rem">${I.clock} داده‌های زنده امروز</div>
                <div class="muted" style="font-size:.74rem;line-height:2">${BANAPI.company}<br>۵۶ مشتری فعال · ۱۰ قلم کالا<br>وظایف در حال انجام: ${faNum(STORE.tasks.filter(t => t.status === 'doing').length)}</div>
            </div>
        </div>
    </div>`;
}
function bindAI() { aiWelcome(); }
function aiAnswer(q) {
    const t = q.trim() + ' ';
    const has = (...kw) => kw.some(k => t.includes(k));
    const nowIdx = SERIES.sales.length - 1;
    const prevIdx = nowIdx - 1;
    if (has('فروش', 'درآمد', 'فروخته')) {
        const best = STORE.customers.filter(c => c.lastPurchase).slice().sort((a, b) => b.balance + (b.lastPurchase >= '2026-09-15' ? 1e9 : 0) - (a.balance + (a.lastPurchase >= '2026-09-15' ? 1e9 : 0))).slice(0, 3);
        return aiMessage('ai', `
            <h4>تحلیل فروش ماه جاری 📊</h4>
            ${aiStats([
                { v: faMv(SERIES.sales[nowIdx]), l: 'فروش ماه' },
                { v: faMv(SERIES.sales[nowIdx] - SERIES.sales[prevIdx]), l: 'رشد نسبت به ماه قبل' },
                { v: faNum(SERIES.profit[nowIdx]) + '٪', l: 'روند سود' }])}
            <p>ماه جاری <b>${faMv(SERIES.sales[nowIdx])}</b> فروش داشته‌ایم که نسبت به ماه قبل <b>${faNum(SERIES.sales[nowIdx] - SERIES.sales[prevIdx])} میلیون تومان</b> بیشتر است.</p>
            <h4>مشتریان برتر ماه</h4>
            <ul>${best.map(c => `<li>${c.company} — ${faMoney(c.balance || 1e6)} ارزش تعهد</li>`).join('')}</ul>
            <h4>پیشنهاد هوشمند</h4>
            <p>۲ فرصت در مرحله «تایید خرید» به مبلغ ${faMoney(1480e6)} در انتظار بسته‌شدن است. با پیگیری امروز، احتمال تحقق ${faNum(78)}٪ است.</p>`);
    }
    if (has('مشتری', 'مشتری‌ها', 'خرید نکرده')) {
        const inactive = STORE.customers.filter(c => !c.lastPurchase || c.lastPurchase < '2026-08-01');
        return aiMessage('ai', `
            <h4>تحلیل مشتریان 👥</h4>
            ${aiStats([
                { v: faNum(STORE.customers.length), l: 'کل مشتریان' },
                { v: faNum(STORE.customers.filter(c => c.status === 'active').length), l: 'مشتری فعال' },
                { v: faNum(inactive.length), l: 'بدون خرید اخیر' }])}
            <p>این مشتریان بیش از ۴۵ روز خرید نداشته‌اند و در معرض ریزش هستند:</p>
            <ul>${inactive.map(c => `<li>${c.company} — ${c.lastPurchase ? 'آخرین خرید: ' + c.lastPurchase : 'هنوز خریدی ثبت نشده'}</li>`).join('')}</ul>
            <p>پیشنهاد: فعال‌سازی کمپین تماس و ارسال لیست قیمت به این ${faNum(inactive.length)} مشتری.</p>`);
    }
    if (has('کالا', 'موجودی', 'انبار', 'اتمام', 'خطر')) {
        const low = STORE.products.filter(p => p.status === 'low');
        return aiMessage('ai', `
            <h4>تحلیل موجودی انبار 📦</h4>
            ${aiStats([
                { v: faNum(low.length), l: 'کالای در خطر' },
                { v: faNum(STORE.products.filter(p => p.status === 'ok').length), l: 'کالای سالم' },
                { v: faMoney(STORE.products.reduce((s, p) => s + p.qty * p.avgCost, 0)), l: 'ارزش موجودی' }])}
            <p>این کالاها زیر حد مجاز موجودی هستند:</p>
            <ul>${low.map(p => `<li>${p.name} — ${faNum(p.qty)} ${p.unit} (حداقل: ${faNum(p.minStock)}). پیشنهاد خرید ${faNum(p.minStock - p.qty + p.minStock)} ${p.unit}</li>`).join('')}</ul>
            <p>گردش کار «هشدار کاهش موجودی» برای این موارد فعال شد.</p>`);
    }
    if (has('هزینه', 'خرج', 'پرداخت')) {
        const top = EXPENSE_CATS.slice().sort((a, b) => b.value - a.value)[0];
        return aiMessage('ai', `
            <h4>تحلیل هزینه‌ها 💰</h4>
            ${aiStats([
                { v: faMv(SERIES.outflow[nowIdx]), l: 'هزینه‌های ماه' },
                { v: faMv(SERIES.outflow[nowIdx] - SERIES.outflow[prevIdx]), l: 'تغییر ماهانه' },
                { v: top.label, l: 'بیشترین هزینه' }])}
            <p>بیشترین هزینه این ماه <b>${top.label}</b> با ${faMv(top.value)} میلیون تومان (${faNum(top.value)}٪ از کل) بوده است. ${faNum(32)}٪ از هزینه‌ها به خرید کالا اختصاص دارد.</p>
            <p>نکته: هزینه حمل و نقل نسبت به میانگین ۳ ماه اخیر ${faNum(9)}٪ بالاتر است — بررسی نرخ‌های حمل پیشنهاد می‌شود.</p>`);
    }
    if (has('وظیفه', 'کار', 'عقب', 'باز')) {
        const late = STORE.tasks.filter(t => t.status !== 'done' && t.due < '2026-09-23');
        const doing = STORE.tasks.filter(t => t.status === 'doing');
        return aiMessage('ai', `
            <h4>وضعیت وظایف ✅</h4>
            ${aiStats([
                { v: faNum(late.length), l: 'وظیفه دیرشده' },
                { v: faNum(doing.length), l: 'در حال انجام' },
                { v: faNum(STORE.tasks.filter(t => t.status === 'done').length), l: 'تکمیل‌شده' }])}
            <p>${late.length ? 'این وظایف از سررسید گذشته‌اند و باید امروز اقدام شوند:' : 'هیچ وظیفه‌ای دیر نشده است. آفرین تیم! 🎉'}</p>
            ${late.length ? `<ul>${late.map(t => `<li>${t.title} — مسئول: ${userOf(t.assignee).name}</li>`).join('')}</ul>` : ''}
            <p>پیشنهاد: ${late.length ? 'اعلان خودکار به مسئولین و افزایش الویت ارسال شد.' : 'مرور وظایف هفته آینده برای برنامه‌ریزی بهتر.'}</p>`);
    }
    if (has('چک', 'سررسید')) {
        const pend = STORE.checks.filter(c => c.status === 'pending');
        const near = pend.filter(c => c.kind === 'received' && (new Date(c.dueDate) - new Date('2026-09-23')) / 86400000 <= 15);
        return aiMessage('ai', `
            <h4>وضعیت چک‌ها 🏦</h4>
            ${aiStats([
                { v: faNum(pend.filter(c => c.kind === 'received').length), l: 'چک دریافتی' },
                { v: faNum(pend.filter(c => c.kind === 'paid').length), l: 'چک پرداختی' },
                { v: faMoney(pend.reduce((s, c) => s + c.amount, 0)), l: 'حجم کل' }])}
            <p>${near.length ? 'چک‌های دریافتی که در ${faNum(15)} روز آینده سررسید می‌شوند:' : 'چکی در بازه نزدیک سررسید نیست.'}</p>
            ${near.length ? `<ul>${near.map(c => `<li>${c.id} — ${faMoney(c.amount)} از ${customerOf(c.payer)?.company} (${c.dueDate})</li>`).join('')}</ul>` : ''}`);
    }
    return aiMessage('ai', `
        <h4>پاسخ هوشمند 🤖</h4>
        <p>سوال شما تحلیل شد اما به دادهٔ مشخصی نرسیدم. پیشنهاد می‌کنم یکی از این سوال‌ها را بپرسید:</p>
        <ul><li>فروش این ماه را تحلیل کن</li><li>کدام مشتری‌ها خرید نکرده‌اند؟</li><li>کدام کالا در خطر اتمام است؟</li><li>کارهای عقب افتاده چیست؟</li></ul>`);
}
function askAI(raw) {
    const q = (document.getElementById('aiInput').value || raw || '').trim();
    if (!q) return;
    const body = document.getElementById('chatBody');
    body.insertAdjacentHTML('beforeend', aiMessage('user', q));
    document.getElementById('aiInput').value = '';
    const typing = document.createElement('div');
    typing.className = 'ai-msg ai';
    typing.innerHTML = `<div class="msg-avatar">${I.robot}</div><div class="msg-bubble"><span class="typing"><span></span><span></span><span></span></span></div>`;
    body.appendChild(typing);
    body.scrollTop = body.scrollHeight;
    setTimeout(() => {
        typing.remove();
        body.insertAdjacentHTML('beforeend', aiAnswer(q));
        body.scrollTop = body.scrollHeight;
        logAudit('دستیار هوش مصنوعی: «' + q + '»', 'AI');
    }, 900);
}

/* ============================================================
   RENDER: SETTINGS / USERS / AUDIT
   ============================================================ */
function pageSettings() {
    const tab = STORE.params.tab || 'profile';
    const isAdmin = STORE.user.role === 'admin';
    const body = tab === 'profile' ? `
        <div class="grid cols-2-1">
            <div class="glass-card panel">
                <div class="panel-head"><div class="panel-title"><span class="pt-icon">${I.users}</span> اطلاعات حساب کاربری</div></div>
                <div class="form-grid">
                    <div><label class="form-label">نام و نام خانوادگی</label><input class="form-input" value="${userOf(STORE.user.id).name}"></div>
                    <div><label class="form-label">نقش سازمانی</label><input class="form-input" value="${ROLES[STORE.user.role].label}" disabled></div>
                    <div><label class="form-label">نام کاربری</label><input class="form-input" value="${userOf(STORE.user.id).username}" dir="ltr"></div>
                    <div><label class="form-label">شماره تماس</label><input class="form-input" value="${userOf(STORE.user.id).phone}" dir="ltr"></div>
                    <div class="full"><label class="form-label">رمز عبور</label><input class="form-input" type="password" value="123456"></div>
                </div>
                <div class="row mt-3"><button class="btn btn-primary" onclick="showToast('success','تغییرات ذخیره شد','پروفایل کاربری به‌روزرسانی شد')">${I.check} ذخیره تغییرات</button></div>
            </div>
            <div class="glass-card panel">
                <div class="panel-head"><div class="panel-title"><span class="pt-icon">${I.gear}</span> ترجیحات</div></div>
                <div class="setting-row"><div class="st-icon">${I.bell}</div><div class="st-main"><div class="st-t">اعلان مرورگر</div><div class="st-s">هشدارهای سیستمی مرورگر</div></div><label class="switch"><input type="checkbox" checked><span class="slider"></span></label></div>
                <div class="setting-row"><div class="st-icon">${I.mail}</div><div class="st-main"><div class="st-t">گزارش ایمیل روزانه</div><div class="st-s">خلاصه مالی هر روز صبح</div></div><label class="switch"><input type="checkbox"><span class="slider"></span></label></div>
                <div class="setting-row"><div class="st-icon">${I.chart}</div><div class="st-main"><div class="st-t">حالت تیره</div><div class="st-s">تم شیشه‌ای آبی پیش‌فرض</div></div><label class="switch"><input type="checkbox" checked><span class="slider"></span></label></div>
            </div>
        </div>` :
        tab === 'users' ? (isAdmin ? `
            <div class="page-head-actions" style="margin-bottom:16px"><button class="btn btn-primary" onclick="showToast('success','کاربر جدید','دسترسی‌ها تعیین و دعوت‌نامه ارسال شد')">${I.plus} افزودن کاربر</button></div>
            <div class="grid cols-4">${USERS.map(u => `
            <div class="glass-card user-card hover">
                <div class="uc-head">
                    <div class="avatar-ring" style="background:${ROLES[u.role].color}">${u.initials}</div>
                    <div><div class="uc-name">${u.name}</div><div class="uc-role">${u.username}</div></div>
                    <span class="pill gray plain" style="margin-inline-start:auto;color:${ROLES[u.role].color};background:${ROLES[u.role].color}22">${ROLES[u.role].label}</span>
                </div>
                <div class="uc-tags">${PERMISSIONS[u.role].filter(p => p !== 'dashboard').slice(0, 5).map(p => {
                    const nm = { customers: 'CRM', pipeline: 'فروش', inventory: 'انبار', accounting: 'مالی', checks: 'چک', tasks: 'وظایف', reports: 'گزارش', automation: 'اتوماسیون', ai: 'AI', purchase: 'تامین' }[p];
                    return nm ? `<span class="perm-tag">${nm}</span>` : '';
                }).join('')}${PERMISSIONS[u.role].length > 5 ? '<span class="perm-tag">+' + faNum(PERMISSIONS[u.role].length - 5) + '</span>' : ''}</div>
                <div class="row" style="justify-content:space-between"><span class="muted" style="font-size:.7rem">آخرین ورود: امروز ۰۹:۱۲</span><button class="btn btn-sm btn-ghost" onclick="showToast('info','ویرایش دسترسی‌ها','دسترسی‌های ' + '${u.name}' + ' باز شد')">${I.gear} مدیریت</button></div>
            </div>`).join('')}</div>` : '<div class="empty-state">' + I.warn + '<div class="es-t">دسترسی محدود</div>تنها مدیر کل امکان مدیریت کاربران را دارد.</div>') :
        tab === 'roles' ? `
            <div class="grid cols-3">${Object.entries(ROLES).map(([k, r]) => `
                <div class="glass-card panel hover">
                    <div class="uc-head"><div class="avatar-ring" style="width:38px;height:38px;background:${r.color}">${r.icon === 'crown' ? '★' : r.icon === 'calc' ? '₿' : r.icon === 'box' ? '◧' : r.icon === 'hand' ? '✋' : r.icon === 'chart' ? '◭' : '✓'}</div>
                    <div><div class="uc-name">${r.label}</div><div class="uc-role">${faNum(PERMISSIONS[k].length)} ماژول دسترسی</div></div></div>
                    <div class="uc-tags">${PERMISSIONS[k].filter(p => p !== 'dashboard').slice(0, 6).map(p => { const nm = { customers: 'CRM', pipeline: 'فروش', inventory: 'انبار', accounting: 'مالی', checks: 'چک', tasks: 'وظایف', reports: 'گزارش', automation: 'اتوماسیون', ai: 'AI', purchase: 'تامین', settings: 'تنظیمات', notifications: 'اعلان', users: 'کاربران', audit: 'تاریخچه' }[p]; return nm ? `<span class="perm-tag">${nm}</span>` : ''; }).join('')}</div>
                </div>`).join('')}</div>` :
        tab === 'products' ? (can('inventory') ? `
            <div class="page-head-actions" style="margin-bottom:16px">
                <button class="btn btn-primary" onclick="openProductModal()">${I.plus} افزودن محصول جدید</button>
                <span class="muted" style="font-size:.74rem">${faNum(STORE.products.length)} قلم کالا تعریف شده است</span>
            </div>
            <div class="grid cols-4">
                ${STORE.products.map(p => `
                <div class="glass-card product-card hover">
                    <div class="pc-top">
                        <div class="pc-thumb">${prodIcon(p)}</div>
                        <div><div class="pc-name">${p.name}</div><div class="pc-cat">${p.cat} · واحد: ${p.unit}</div></div>
                    </div>
                    <div class="pc-features">${featBadges(p.features)}</div>
                    <div class="pc-specs">
                        <div class="pc-spec"><div class="cs">موجودی فعلی</div><div class="cv">${faNum(p.qty)} ${p.unit}</div></div>
                        <div class="pc-spec"><div class="cs">وزن واحد</div><div class="cv">${faNum(p.weight)} کیلوگرم</div></div>
                        <div class="pc-spec"><div class="cs">قیمت فروش</div><div class="cv">${faMoney(p.sellPrice)}</div></div>
                        <div class="pc-spec"><div class="cs">بهای تمام‌شده</div><div class="cv">${faMoney(p.avgCost)}</div></div>
                    </div>
                    <div class="pc-foot">
                        <span class="pill ${p.status === 'low' ? 'amber' : 'green'}">${p.status === 'low' ? 'هشدار' : 'مطلوب'}</span>
                        <button class="btn btn-sm btn-ghost" onclick="openStockModal('${p.id}')">${I.gear} عملیات</button>
                    </div>
                </div>`).join('')}
            </div>` : '<div class="empty-state">' + I.warn + '<div class="es-t">دسترسی محدود</div>تنها کاربران دارای دسترسی انبار می‌توانند محصول تعریف کنند.</div>') :
        tab === 'data' ? (isAdmin ? `
            <div class="glass-card panel" style="border-color:rgba(251,113,133,.25)">
                <div class="panel-head"><div class="panel-title"><span class="pt-icon" style="background:var(--red-dim);color:var(--red)">${I.warn}</span> منطقه خطر — پاکسازی همه داده‌ها</div></div>
                <div class="wipe-note">
                    با این عملیات همه مشتریان، تامین‌کنندگان، فاکتورها، هزینه‌ها، چک‌ها، فرصت‌های فروش، وظایف، اعلان‌ها، جلسات و گزارش‌های عملیات حذف می‌شوند.
                    <br>اطلاعات کاربران، نقش‌ها، دسترسی‌ها، کاتالوگ کالا و تنظیمات اتوماسیون محفوظ می‌ماند.
                </div>
                <div class="row mt-3" style="justify-content:space-between;align-items:center">
                    <span class="muted" style="font-size:.72rem">تعداد مشتری فعلی: ${faNum(STORE.customers.length)} · تعداد فاکتور: ${faNum(STORE.invoices.length)} · تعداد هزینه ثبت‌شده: ${faNum(0)}</span>
                    <button class="btn btn-danger" onclick="confirmWipe()">${I.warn} پاکسازی کامل داده‌ها</button>
                </div>
            </div>` : '<div class="empty-state">' + I.warn + '<div class="es-t">دسترسی محدود</div>تنها مدیر کل امکان پاکسازی داده‌ها را دارد.</div>') :
        tab === 'audit' ? `
            <div class="glass-card panel">
                <div class="panel-head"><div class="panel-title"><span class="pt-icon">${I.clock}</span> گزارش عملیات (Audit Log)</div></div>
                <div style="max-height:520px;overflow-y:auto">
                ${STORE.audit.map(a => `<div class="audit-item">
                    <div class="audit-avatar">${a.user.charAt(0)}</div>
                    <div class="audit-main"><div class="audit-action"><span class="audit-mod">${a.module}</span> ${a.action}</div><div class="audit-time">${a.date} · ${a.time} · توسط ${a.user}</div></div>
                </div>`).join('')}
                </div>
            </div>` : '';
    return `
    <div class="page-head">
        <div><h2>${PAGES.settings.title}</h2><div class="sub">${isAdmin ? 'دسترسی کامل مدیر کل' : 'دسترسی بر اساس نقش «' + ROLES[STORE.user.role].label + '»'}</div></div>
    </div>
    <div class="tabs">
        ${[['profile', 'پروفایل من'], ['roles', 'نقش‌ها و دسترسی‌ها']].map(([k, l]) => `<button class="tab-btn ${tab===k?'active':''}" onclick="STORE.params.tab='${k}';renderPage()">${l}</button>`).join('')}
        ${isAdmin ? `<button class="tab-btn ${tab==='users'?'active':''}" onclick="STORE.params.tab='users';renderPage()">کاربران</button>` : ''}
        <button class="tab-btn ${tab==='audit'?'active':''}" onclick="STORE.params.tab='audit';renderPage()">گزارش عملیات</button>
        ${can('inventory') ? `<button class="tab-btn ${tab==='products'?'active':''}" onclick="STORE.params.tab='products';renderPage()">${I.box} محصولات</button>` : ''}
        ${isAdmin ? `<button class="tab-btn ${tab==='data'?'active':''}" onclick="STORE.params.tab='data';renderPage()" style="color:var(--red)">پاکسازی داده‌ها</button>` : ''}
    </div>
    ${body}`;
}

/* ============================================================
   RENDER: NOTIFICATIONS PAGE
   ============================================================ */
function pageNotifs() {
    const flt = STORE.params.nflt || 'all';
    let list = STORE.notifs;
    if (flt !== 'all') list = list.filter(n => n.type === flt);
    const count = STORE.notifs.filter(n => !n.read).length;
    return `
    <div class="page-head">
        <div><h2>${PAGES.notifications.title}</h2><div class="sub">${faNum(count)} اعلان خوانده‌نشده</div></div>
        <div class="page-head-actions"><button class="btn btn-ghost" onclick="markAllRead()">${I.check} علامت‌گذاری همه</button></div>
    </div>
    <div class="filter-bar" style="justify-content:center">
        <div class="seg">${[['all', 'همه'], ['finance', 'مالی'], ['inventory', 'انبار'], ['task', 'وظایف'], ['crm', 'مشتری'], ['system', 'سیستمی']].map(([k, l]) => `<button class="${flt===k?'active':''}" onclick="STORE.params.nflt='${k}';renderPage()">${l}</button>`).join('')}</div>
    </div>
    <div class="notif-list">
        ${list.map(n => { const s = notifStyle(n.type); return `<div class="glass-card notif-card ${n.read ? '' : 'unread'}" onclick="markNotifRead('${n.id}')">
            <div class="nc-icon" style="background:${s.bg};color:${s.fg}">${I[s.icon]}</div>
            <div style="min-width:0;flex:1"><div class="li-t">${n.title}</div><div class="li-s">${n.body}</div><div class="nc-time">${n.time}</div></div>
            ${n.read ? '' : '<span class="pi-dot" style="margin-inline-start:auto;margin-top:8px"></span>'}
        </div>`; }).join('')}
    </div>`;
}

/* ============================================================
   MODALS
   ============================================================ */
function openNewCustomerModal() {
    openModal(`
        <div class="modal-head"><h3>${I.users} افزودن مشتری جدید</h3><button class="modal-close" onclick="closeModal()">${I.x}</button></div>
        <div class="modal-body">
            <div class="form-grid">
                <div><label class="form-label">نام مشتری</label><input class="form-input" id="ncName" placeholder="نام و نام خانوادگی"></div>
                <div><label class="form-label">شرکت</label><input class="form-input" id="ncComp" placeholder="نام شرکت"></div>
                <div><label class="form-label">شماره تماس</label><input class="form-input" id="ncPhone" dir="ltr" placeholder="09xxxxxxxxx"></div>
                <div><label class="form-label">نوع مشتری</label><select class="form-input" id="ncType"><option>سازنده</option><option>پیمانکار</option><option>عمده‌فروش</option><option>خرده‌فروش</option><option>مشاور</option></select></div>
                <div><label class="form-label">پروژه جاری</label><input class="form-input" id="ncProj" placeholder="نام پروژه"></div>
                <div><label class="form-label">شهر</label><input class="form-input" id="ncCity" placeholder="شهر"></div>
                <div class="full"><label class="form-label">مسئول فروش</label><select class="form-input" id="ncOwner">${USERS.filter(u => ['seller', 'sales_manager'].includes(u.role)).map(u => `<option value="${u.id}">${u.name}</option>`).join('')}</select></div>
            </div>
        </div>
        <div class="modal-foot"><button class="btn btn-ghost" onclick="closeModal()">انصراف</button><button class="btn btn-primary" onclick="saveNewCustomer()">${I.check} ثبت مشتری و اجرای اتوماسیون</button></div>`);
}
function saveNewCustomer() {
    const name = document.getElementById('ncName').value;
    if (!name) { showToast('error', 'نام مشتری الزامی است'); return; }
    const id = 'c' + (Date.now() % 100000);
    STORE.customers.push({ id, name, company: document.getElementById('ncComp').value || name, phone: document.getElementById('ncPhone').value || '—', type: document.getElementById('ncType').value, project: document.getElementById('ncProj').value, city: document.getElementById('ncCity').value, owner: document.getElementById('ncOwner').value, lastPurchase: null, balance: 0, credit: 0, status: 'lead', stage: 'new' });
    logAudit('مشتری جدید «' + name + '» در CRM ثبت شد', 'CRM');
    const fired = triggerAutomations('مشتری جدید', 'new customer');
    addNotif('crm', 'مشتری جدید ثبت شد', name + ' — اتوماسیون پیگیری فعال شد');
    fired.forEach(f => f.results.forEach(r => { /* silent */ }));
    showToast('success', 'مشتری جدید ثبت شد', name + ' — گردش کار پیگیری اجرا شد');
    closeModal();
    STORE._toastDone = true;
    navigateTo('customers');
}
function openNewInvoiceModal(cid) {
    const custs = STORE.customers.map(c => `<option ${c.id === cid ? 'selected' : ''} value="${c.id}">${c.company}</option>`).join('');
    openModal(`
        <div class="modal-head"><h3>${I.doc} صدور فاکتور فروش</h3><button class="modal-close" onclick="closeModal()">${I.x}</button></div>
        <div class="modal-body">
            <div class="form-grid">
                <div class="full"><label class="form-label">مشتری</label><select class="form-input" id="nfCust">${custs}</select></div>
                <div class="full"><label class="form-label">شرح اقلام</label><input class="form-input" id="nfItems" placeholder="مثلاً میلگرد ۱۴ — ۵۰ شاخه"></div>
                <div><label class="form-label">مبلغ کل (تومان)</label><input class="form-input" id="nfAmt" type="number" placeholder="150000000"></div>
                <div><label class="form-label">تاریخ</label><input class="form-input" id="nfDate" type="date" value="2026-09-23"></div>
            </div>
            <div class="mt-2" style="display:flex;gap:8px;align-items:center;background:rgba(0,200,255,.07);border:1px solid rgba(0,200,255,.2);border-radius:12px;padding:10px 14px">
                ${I.spark}<span class="muted" style="font-size:.75rem">با ثبت فاکتور، یادآوری پیگیری و تسویه به صورت خودکار برای تیم ایجاد می‌شود.</span>
            </div>
        </div>
        <div class="modal-foot"><button class="btn btn-ghost" onclick="closeModal()">انصراف</button><button class="btn btn-primary" onclick="saveNewInvoice()">${I.send} ثبت و ارسال</button></div>`);
}
function saveNewInvoice() {
    const c = document.getElementById('nfCust').value;
    const amt = Number(document.getElementById('nfAmt').value) || 0;
    const items = document.getElementById('nfItems').value || 'اقلام فاکتور';
    if (!c || !amt) { showToast('error', 'مشتری و مبلغ الزامی است'); return; }
    const id = 'INV-1043';
    STORE.invoices.unshift({ id, customer: c, date: document.getElementById('nfDate').value, items, amount: amt, paid: 0, status: 'unpaid', type: 'فروش' });
    STORE.deals.push({ id: 'd' + Date.now(), customer: c, stage: 'approval', amount: amt, seller: STORE.user.id, due: '2026-09-28', product: items });
    logAudit('فاکتور فروش شماره ' + id + ' ثبت شد', 'حسابداری');
    const names = { in1: 'task' };
    STORE.tasks.unshift({ id: 't' + Date.now(), title: 'یادآوری پیگیری فاکتور ' + id, descr: 'تماس با مشتری برای پیگیری فاکتور — ایجاد خودکار', assignee: STORE.user.id, creator: 'auto', priority: 'high', status: 'todo', due: '2026-09-26', ref: 'اتوماسیون', customer: c, tags: ['حسابداری'] });
    addNotif('task', 'یادآوری پیگیری ایجاد شد', 'فاکتور ' + id + ' — پیگیری پس از ۳ روز');
    showToast('success', 'فاکتور ثبت شد', 'مبلغ ' + faMoney(amt) + ' — یادآوری خودکار فعال شد');
    closeModal();
    navigateTo('invoices');
}
function openNewDealModal() {
    openModal(`
        <div class="modal-head"><h3>${I.target} فرصت فروش جدید</h3><button class="modal-close" onclick="closeModal()">${I.x}</button></div>
        <div class="modal-body">
            <div class="form-grid">
                <div class="full"><label class="form-label">مشتری</label><select class="form-input" id="ndCust">${STORE.customers.map(c => `<option value="${c.id}">${c.company}</option>`).join('')}</select></div>
                <div class="full"><label class="form-label">شرح کالا</label><input class="form-input" id="ndProd" placeholder="میلگرد ۱۴ — ۱۰۰ شاخه"></div>
                <div><label class="form-label">مبلغ تخمینی (تومان)</label><input class="form-input" id="ndAmt" type="number" placeholder="300000000"></div>
                <div><label class="form-label">تاریخ بستن</label><input class="form-input" id="ndDue" type="date" value="2026-10-05"></div>
            </div>
        </div>
        <div class="modal-foot"><button class="btn btn-ghost" onclick="closeModal()">انصراف</button><button class="btn btn-primary" onclick="saveNewDeal()">${I.plus} افزودن به قیف</button></div>`);
}
function saveNewDeal() {
    const c = document.getElementById('ndCust').value;
    const amt = Number(document.getElementById('ndAmt').value) || 0;
    const prod = document.getElementById('ndProd').value || '—';
    STORE.deals.push({ id: 'd' + Date.now(), customer: c, stage: 'new', amount: amt, seller: STORE.user.id, due: document.getElementById('ndDue').value, product: prod });
    logAudit('فرصت فروش جدید برای «' + cmpName(c) + '» ثبت شد', 'فروش');
    showToast('success', 'فرصت جدید در قیف', faMoney(amt));
    closeModal();
    navigateTo('pipeline');
}
function openJournalModal() {
    const cats = (INCOME_CATS || []).map(x => x.label).concat((EXPENSE_CATS || []).map(x => x.label));
    openModal(`
        <div class="modal-head"><h3>${I.coin} ثبت سند حسابداری</h3><button class="modal-close" onclick="closeModal()">${I.x}</button></div>
        <div class="modal-body">
            <div class="form-grid">
                <div><label class="form-label">نوع سند</label><select class="form-input" id="njType"><option value="درآمد">درآمد</option><option value="هزینه">هزینه</option></select></div>
                <div><label class="form-label">تاریخ</label><input class="form-input" type="date" id="njDate" value="2026-09-23"></div>
                <div class="full"><label class="form-label">شرح سند</label><input class="form-input" id="njTitle" placeholder="مثلاً: فروش نقدی وامصار، کرایه حمل شن"></div>
                <div><label class="form-label">دسته‌بندی</label><select class="form-input" id="njCat">${cats.map(c => `<option>${c}</option>`).join('')}</select></div>
                <div><label class="form-label">مبلغ (تومان)</label><input class="form-input" id="njAmt" type="number" value="0" dir="ltr"></div>
            </div>
            <p class="form-hint">سند ثبت‌شده در دفتر روزنامه حسابداری اعمال و در آمار درآمد/هزینه ماه جاری لحاظ می‌شود.</p>
        </div>
        <div class="modal-foot"><button class="btn btn-ghost" onclick="closeModal()">انصراف</button><button class="btn btn-primary" onclick="saveJournalEntry()">${I.check} ثبت سند</button></div>`);
}
function saveJournalEntry() {
    const type = document.getElementById('njType').value;
    const title = document.getElementById('njTitle').value.trim();
    const amount = Number(document.getElementById('njAmt').value) || 0;
    const cat = document.getElementById('njCat').value;
    if (!title) { showToast('error', 'شرح سند الزامی است'); return; }
    if (!amount) { showToast('error', 'مبلغ سند الزامی است'); return; }
    STORE.journal.unshift({ id: 'sn' + Date.now(), type, title, amount, cat, date: document.getElementById('njDate').value || '2026-09-23' });
    if (type === 'درآمد') SERIES.inflow[11] += amount / 1e6; else SERIES.outflow[11] += amount / 1e6;
    logAudit('سند «' + title + '» (' + type + ' · ' + faMoney(amount) + ') در دفتر روزنامه ثبت شد', 'حسابداری');
    showToast('success', 'سند ثبت شد', type + ' · ' + faMoney(amount));
    closeModal();
    renderPage();
}
function openCheckModal() {
    const custs = STORE.customers.map(c => `<option value="${c.id}">${c.company}</option>`).join('') || '<option value="">— مشتری ثبت نشده —</option>';
    const supps = SUPPLIERS.map(s => `<option value="${s.id}">${s.name}</option>`).join('') || '<option value="">— تامین‌کننده ثبت نشده —</option>';
    openModal(`
        <div class="modal-head"><h3>${I.bank} ثبت چک جدید</h3><button class="modal-close" onclick="closeModal()">${I.x}</button></div>
        <div class="modal-body">
            <div class="form-grid">
                <div><label class="form-label">نوع چک</label><select class="form-input" id="nckKind"><option value="received">دریافتی (مطالبات)</option><option value="paid">پرداختی (تعهدات)</option></select></div>
                <div><label class="form-label">شماره چک</label><input class="form-input" id="nckNum" dir="ltr" placeholder="105421"></div>
                <div><label class="form-label">بانک</label><select class="form-input" id="nckBank"><option>ملت</option><option>ملی</option><option>صادرات</option><option>تجارت</option><option>سپه</option><option>پاسارگاد</option><option>سایر</option></select></div>
                <div><label class="form-label">صادرکننده (دریافتی)</label><select class="form-input" id="nckCust">${custs}</select></div>
                <div><label class="form-label">ذی‌نفع (پرداختی)</label><select class="form-input" id="nckSupp">${supps}</select></div>
                <div><label class="form-label">سررسید</label><input class="form-input" type="date" id="nckDue" value="2026-10-15"></div>
                <div><label class="form-label">مبلغ (تومان)</label><input class="form-input" id="nckAmt" type="number" value="0" dir="ltr"></div>
                <div class="full"><label class="form-label">توضیحات</label><input class="form-input" id="nckNote" placeholder="اختیاری"></div>
            </div>
        </div>
        <div class="modal-foot"><button class="btn btn-ghost" onclick="closeModal()">انصراف</button><button class="btn btn-primary" onclick="saveCheck()">${I.check} ثبت چک</button></div>`);
}
function saveCheck() {
    const kind = document.getElementById('nckKind').value;
    const amount = Number(document.getElementById('nckAmt').value) || 0;
    const number = document.getElementById('nckNum').value.trim();
    const bank = document.getElementById('nckBank').value;
    const dueDate = document.getElementById('nckDue').value;
    const payer = kind === 'received' ? document.getElementById('nckCust').value : document.getElementById('nckSupp').value;
    if (!amount) { showToast('error', 'مبلغ چک الزامی است'); return; }
    if (!number) { showToast('error', 'شماره چک الزامی است'); return; }
    if (!payer) { showToast('error', kind === 'received' ? 'مشتری صادرکننده را انتخاب کنید' : 'تامین‌کننده ذی‌نفع را انتخاب کنید'); return; }
    STORE.checks.unshift({ id: 'CK-' + faNum(Date.now() % 100000), kind, payer, number, bank, dueDate, amount, status: 'pending', note: document.getElementById('nckNote').value.trim() });
    logAudit('چک «' + number + '» از بانک ' + bank + ' (' + (kind === 'received' ? 'دریافتی' : 'پرداختی') + ' · ' + faMoney(amount) + ') ثبت شد', 'چک‌ها');
    addNotif('finance', 'چک جدید ثبت شد', (kind === 'received' ? 'چک دریافتی' : 'چک پرداختی') + ' ' + faMoney(amount) + ' · پیگیری خودکار سررسید فعال شد');
    showToast('success', 'چک ثبت شد', (kind === 'received' ? 'دریافتی' : 'پرداختی') + ' · ' + faMoney(amount));
    closeModal();
    renderPage();
}
function openMeetingModal() {
    const days = Array.from({ length: 30 }, (_, i) => i + 1).map(d => `<option value="${d}">${faNum(d)}</option>`).join('');
    openModal(`
        <div class="modal-head"><h3>${I.calendar} جلسه جدید</h3><button class="modal-close" onclick="closeModal()">${I.x}</button></div>
        <div class="modal-body">
            <div class="form-grid">
                <div class="full"><label class="form-label">عنوان جلسه</label><input class="form-input" id="nmTitle" placeholder="مثلاً: بازدید پروژه شهرک غرب"></div>
                <div><label class="form-label">ماه</label><select class="form-input" id="nmMonth"><option value="مهر">مهر ۱۴۰۵</option><option value="آبان">آبان ۱۴۰۵</option></select></div>
                <div><label class="form-label">روز</label><select class="form-input" id="nmDay">${days}</select></div>
                <div><label class="form-label">ساعت</label><input class="form-input" id="nmTime" value="10:00" dir="ltr"></div>
                <div><label class="form-label">نوع</label><select class="form-input" id="nmType"><option>مشتری</option><option>فروش</option><option>انبار</option><option>مالی</option><option>تیم</option></select></div>
                <div class="full"><label class="form-label">توضیحات</label><textarea class="form-input" id="nmNote" placeholder="اختیاری"></textarea></div>
            </div>
        </div>
        <div class="modal-foot"><button class="btn btn-ghost" onclick="closeModal()">انصراف</button><button class="btn btn-primary" onclick="saveMeeting()">${I.check} ثبت جلسه</button></div>`);
}
function saveMeeting() {
    const title = document.getElementById('nmTitle').value.trim();
    const day = Number(document.getElementById('nmDay').value) || 1;
    const time = document.getElementById('nmTime').value || '10:00';
    const month = document.getElementById('nmMonth').value;
    const type = document.getElementById('nmType').value;
    if (!title) { showToast('error', 'عنوان جلسه الزامی است'); return; }
    MEETINGS.push({ month, day, time, title, type });
    logAudit('جلسه «' + title + '» در تقویم (' + faNum(day) + ' ' + month + ') ثبت شد', 'تقویم');
    showToast('success', 'جلسه ثبت شد', faNum(day) + ' ' + month + ' · ' + time);
    closeModal();
    renderPage();
}
function openNewTaskModal() {
    openModal(`
        <div class="modal-head"><h3>${I.task} وظیفه جدید</h3><button class="modal-close" onclick="closeModal()">${I.x}</button></div>
        <div class="modal-body">
            <div class="form-grid">
                <div class="full"><label class="form-label">عنوان وظیفه</label><input class="form-input" id="ntTitle" placeholder="عنوان وظیفه"></div>
                <div class="full"><label class="form-label">توضیحات</label><textarea class="form-input" id="ntDesc" placeholder="توضیحات"></textarea></div>
                <div class="full">
                    <label class="form-label">آیکون وظیفه</label>
                    <div class="icon-picker">
                        ${TASK_ICONS.map(ic => `<label class="icon-opt"><input type="radio" name="ntIcon" value="${ic}" ${ic === '📌' ? 'checked' : ''}><span>${ic}</span></label>`).join('')}
                    </div>
                </div>
                <div><label class="form-label">مسئول</label><select class="form-input" id="ntAs">${USERS.map(u => `<option value="${u.id}">${u.name}</option>`).join('')}</select></div>
                <div><label class="form-label">اولویت</label><select class="form-input" id="ntPr"><option value="medium">متوسط</option><option value="high">زیاد</option><option value="urgent">فوری</option><option value="low">کم</option></select></div>
                <div><label class="form-label">سررسید</label><input class="form-input" type="date" id="ntDue" value="2026-09-30"></div>
                <div><label class="form-label">پیوست</label><button class="btn btn-ghost" style="width:100%" onclick="showToast('info','پیوست','فایل ضمیمه شد')">${I.file} افزودن فایل</button></div>
            </div>
        </div>
        <div class="modal-foot"><button class="btn btn-ghost" onclick="closeModal()">انصراف</button><button class="btn btn-primary" onclick="saveNewTask()">${I.check} ایجاد وظیفه</button></div>`);
}
function saveNewTask() {
    const t = document.getElementById('ntTitle').value;
    if (!t) { showToast('error', 'عنوان وظیفه الزامی است'); return; }
    STORE.tasks.unshift({ id: 't' + Date.now(), title: t, descr: document.getElementById('ntDesc').value, icon: (document.querySelector('input[name="ntIcon"]:checked') || {}).value || '📌', assignee: document.getElementById('ntAs').value, creator: STORE.user.id, priority: document.getElementById('ntPr').value, status: 'todo', due: document.getElementById('ntDue').value, ref: 'دستی', customer: '', tags: ['دستی'] });
    logAudit('وظیفه «' + t + '» ایجاد شد', 'وظایف');
    showToast('success', 'وظیفه ایجاد شد', 'به مسئول مربوطه اعلان ارسال شد');
    closeModal();
    navigateTo('tasks');
}
function openStockModal(pid) {
    openModal(`
        <div class="modal-head"><h3>${I.box} عملیات انبار</h3><button class="modal-close" onclick="closeModal()">${I.x}</button></div>
        <div class="modal-body">
            <div class="form-grid">
                <div class="full"><label class="form-label">کالا</label><select class="form-input" id="nsProd">${STORE.products.map(p => `<option value="${p.id}" ${p.id === pid ? 'selected' : ''}>${p.name}</option>`).join('')}</select></div>
                <div><label class="form-label">نوع عملیات</label><select class="form-input" id="nsOp"><option value="in">ورود کالا</option><option value="out">خروج کالا</option></select></div>
                <div><label class="form-label">تعداد (${'واحد'})</label><input class="form-input" id="nsQty" type="number" value="10"></div>
            </div>
        </div>
        <div class="modal-foot"><button class="btn btn-ghost" onclick="closeModal()">انصراف</button><button class="btn btn-primary" onclick="saveStockOp()">${I.check} ثبت عملیات</button></div>`);
}
function saveStockOp() {
    const p = STORE.products.find(x => x.id === document.getElementById('nsProd').value);
    const q = Number(document.getElementById('nsQty').value) || 0;
    const op = document.getElementById('nsOp').value;
    if (!p || !q) { showToast('error', 'مشخصات ناقص است'); return; }
    if (op === 'in') p.qty += q; else p.qty = Math.max(0, p.qty - q);
    p.status = p.qty < p.minStock ? 'low' : 'ok';
    logAudit((op === 'in' ? 'وارد' : 'خارج') + ' شد: ' + faNum(q) + ' ' + p.unit + ' ' + p.name, 'انبار');
    if (p.status === 'low') addNotif('inventory', 'موجودی ' + p.name + ' کم شده است', 'موجودی فعلی ' + faNum(p.qty) + ' از حد مجاز کمتر شد');
    showToast('success', 'عملیات انبار ثبت شد', p.name + ': ' + faNum(p.qty) + ' ' + p.unit);
    closeModal();
    renderPage();
}
function openProductModal() {
    openModal(`
        <div class="modal-head"><h3>${I.box} افزودن محصول جدید</h3><button class="modal-close" onclick="closeModal()">${I.x}</button></div>
        <div class="modal-body">
            <div class="form-grid">
                <div class="full"><label class="form-label">نام کالا</label><input class="form-input" id="npName" placeholder="مثلاً: میلگرد ۱۸"></div>
                <div class="full">
                    <label class="form-label">آیکون محصول</label>
                    <div class="icon-picker">
                        ${PRODUCT_ICONS.map(ic => `<label class="icon-opt"><input type="radio" name="npIcon" value="${ic}" ${ic === CAT_EMOJI['میلگرد'] ? 'checked' : ''}><span>${ic}</span></label>`).join('')}
                    </div>
                </div>
                <div><label class="form-label">دسته‌بندی</label><select class="form-input" id="npCat" onchange="selectIconByCat()"><option>میلگرد</option><option>پروفیل</option><option>ورق</option><option>سیمان</option><option>سایر</option></select></div>
                <div><label class="form-label">واحد پایه</label><select class="form-input" id="npUnit"><option>شاخه</option><option>تن</option><option>پاکت</option><option>ورق</option><option>عدد</option></select></div>
                <div><label class="form-label">وزن واحد (کیلوگرم)</label><input class="form-input" id="npWeight" type="number" value="0"></div>
                <div><label class="form-label">حداقل موجودی مجاز</label><input class="form-input" id="npMin" type="number" value="0"></div>
                <div><label class="form-label">موجودی اولیه</label><input class="form-input" id="npQty" type="number" value="0"></div>
                <div><label class="form-label">قیمت خرید (تومان)</label><input class="form-input" id="npBuy" type="number" value="0" dir="ltr"></div>
                <div><label class="form-label">قیمت فروش (تومان)</label><input class="form-input" id="npSell" type="number" value="0" dir="ltr"></div>
                <div class="full">
                    <label class="form-label">ویژگی‌های محصول (نحوه عرضه)</label>
                    <div class="feat-picker">
                        ${PRODUCT_FEATURES.map(f => `<label class="feat-opt"><input type="checkbox" id="npF-${f.key}" checked value="${f.key}"><span>${f.label}</span></label>`).join('')}
                    </div>
                    <p class="form-hint">مثال: میلگرد هم «تناژی (وزنی)» و هم «ظرفیتی (عددی)» عرضه می‌شود؛ سیمان پاکتی فقط «پاکتی» و فله فقط «تناژی».</p>
                </div>
            </div>
        </div>
        <div class="modal-foot"><button class="btn btn-ghost" onclick="closeModal()">انصراف</button><button class="btn btn-primary" onclick="saveProduct()">${I.check} ثبت محصول</button></div>`);
}
function selectIconByCat() {
    const cat = document.getElementById('npCat').value;
    const ic = CAT_EMOJI[cat];
    document.querySelectorAll('input[name="npIcon"]').forEach(rd => { rd.checked = rd.value === ic; });
}
function saveProduct() {
    const name = document.getElementById('npName').value.trim();
    if (!name) { showToast('error', 'نام کالا الزامی است'); return; }
    const features = PRODUCT_FEATURES.filter(f => document.getElementById('npF-' + f.key).checked).map(f => f.key);
    if (!features.length) { showToast('error', 'حداقل یک ویژگی انتخاب کنید', 'مثلاً تناژی یا ظرفیتی'); return; }
    const cat = document.getElementById('npCat').value;
    const icon = (document.querySelector('input[name="npIcon"]:checked') || {}).value || CAT_EMOJI[cat] || '📦';
    const p = {
        id: 'p' + Date.now(),
        name,
        cat,
        icon,
        unit: document.getElementById('npUnit').value,
        weight: Number(document.getElementById('npWeight').value) || 0,
        minStock: Number(document.getElementById('npMin').value) || 0,
        qty: Number(document.getElementById('npQty').value) || 0,
        buyPrice: Number(document.getElementById('npBuy').value) || 0,
        avgCost: Number(document.getElementById('npBuy').value) || 0,
        sellPrice: Number(document.getElementById('npSell').value) || 0,
        status: 'ok',
        features,
        trend: [0, 0, 0, 0, 0, 0, 0, 0],
    };
    p.status = (p.qty > 0 && p.qty < p.minStock) ? 'low' : 'ok';
    STORE.products.unshift(p);
    logAudit('محصول جدید «' + name + '» با ویژگی‌های ' + features.map(featLabel).join(' و ') + ' تعریف شد', 'انبار');
    addNotif('inventory', 'کالای جدید «' + name + '» ثبت شد', features.map(featLabel).join('، '));
    showToast('success', 'محصول ثبت شد', name + ' · ' + features.map(featLabel).join('، '));
    closeModal();
    renderPage();
}
function openWorkflowModal() {
    openModal(`
        <div class="modal-head"><h3>${I.spark} ساخت گردش کار جدید</h3><button class="modal-close" onclick="closeModal()">${I.x}</button></div>
        <div class="modal-body">
            <div class="form-grid">
                <div class="full"><label class="form-label">نام گردش کار</label><input class="form-input" id="nwName" placeholder="مثلاً: پیگیری چک سررسیدشده"></div>
                <div class="full"><label class="form-label">رویداد محرک (WHEN)</label><select class="form-input" id="nwTrig"><option>مشتری جدید ایجاد شد</option><option>فاکتور بعد از ۳۰ روز پرداخت نشد</option><option>موجودی کالا زیر حد مجاز شد</option><option>چک سررسید دریافت شد</option></select></div>
                <div class="full"><label class="form-label">اقدام (THEN)</label><select class="form-input" id="nwAct"><option>ایجاد وظیفه پیگیری</option><option>اعلان به مسئول مربوطه</option><option>زمان‌بندی تماس</option><option>ارسال پیام یادآوری</option></select></div>
            </div>
            <div class="mt-2" style="display:flex;gap:8px;align-items:center;background:rgba(0,200,255,.07);border:1px solid rgba(0,200,255,.2);border-radius:12px;padding:10px 14px">
                ${I.spark}<span class="muted" style="font-size:.75rem">گردش کارها به محض وقوع رویداد به صورت خودکار اجرا می‌شوند.</span>
            </div>
        </div>
        <div class="modal-foot"><button class="btn btn-ghost" onclick="closeModal()">انصراف</button><button class="btn btn-primary" onclick="saveWorkflow()">${I.check} ساخت و فعال‌سازی</button></div>`);
}
function saveWorkflow() {
    const name = document.getElementById('nwName').value || 'گردش کار جدید';
    const trig = document.getElementById('nwTrig').value;
    const act = document.getElementById('nwAct').value;
    const icons = { 'ایجاد وظیفه پیگیری': 'task', 'اعلان به مسئول مربوطه': 'bell', 'زمان‌بندی تماس': 'clock', 'ارسال پیام یادآوری': 'send' };
    const colors = { 'ایجاد وظیفه پیگیری': '#7C6CFF', 'اعلان به مسئول مربوطه': '#00C8FF', 'زمان‌بندی تماس': '#34D399', 'ارسال پیام یادآوری': '#8B5CF6' };
    STORE.workflows.unshift({ id: 'wf' + Date.now(), name, enabled: true, trigger: trig, nodes: [{ type: 'trigger', icon: 'spark', label: 'WHEN', text: trig, color: '#38BDF8' }, { type: 'action', icon: icons[act], label: 'THEN', text: act + ' — «' + name + '»', color: colors[act] }] });
    logAudit('گردش کار «' + name + '» ساخته شد', 'اتوماسیون');
    showToast('success', 'گردش کار فعال شد', 'رویداد: ' + trig);
    closeModal();
    navigateTo('automation');
}

/* ============================================================
   CHARTS HELPERS
   ============================================================ */
const CH_REF = {};
function mkChart(id, cfg) {
    if (CH_REF[id]) { CH_REF[id].destroy(); delete CH_REF[id]; }
    const el = document.getElementById(id);
    if (!el) return;
    const defOpts = {
        responsive: true, maintainAspectRatio: false,
        plugins: {
            legend: { display: cfg.Legend === false ? false : true, labels: { color: 'rgba(234,242,255,.6)', font: { family: 'Vazirmatn', size: 11 }, usePointStyle: true, pointStyleWidth: 8, boxHeight: 6 } },
        },
        tooltips: { enabled: true },
        interaction: { mode: 'index', intersect: false },
        scales: cfg.Scales === false || cfg.type === 'doughnut' ? undefined : {
            x: { grid: { color: 'rgba(255,255,255,.05)' }, ticks: { color: 'rgba(234,242,255,.5)', font: { family: 'Vazirmatn', size: 10 } }, border: { display: false } },
            y: { grid: { color: 'rgba(255,255,255,.06)' }, ticks: { color: 'rgba(234,242,255,.45)', font: { family: 'Vazirmatn', size: 10 } }, border: { display: false }, beginAtZero: true },
        },
        cutout: cfg.Cutout || undefined,
    };
    const config = { type: cfg.type, data: cfg.data, options: defOpts };
    if (typeof window.Chart === 'undefined') return;
    CH_REF[id] = new window.Chart(el.getContext('2d'), config);
}
if (typeof window.Chart !== 'undefined') {
    window.Chart.defaults.font.family = 'Vazirmatn';
    window.Chart.defaults.color = 'rgba(234,242,255,.65)';
}

/* ============================================================
   SEARCH
   ============================================================ */
function handleGlobalSearch(val) {
    const box = document.getElementById('searchResults');
    const q = norm(val || '').trim();
    if (!q) { box.classList.remove('show'); return; }
    const groups = [];
    const cs = STORE.customers.filter(c => norm(c.name + c.company + c.phone + c.project).includes(q)).slice(0, 4);
    if (cs.length) groups.push(['مشتریان', 'users', cs.map(c => ({ t: c.company, s: c.name + ' · ' + (c.project || ''), icon: 'users', go: () => navigateTo('customers', { id: c.id }) }))]);
    const pd = STORE.products.filter(p => norm(p.name + p.cat).includes(q)).slice(0, 4);
    if (pd.length) groups.push(['کالاها', 'inventory', pd.map(p => ({ t: p.name, s: p.cat + ' · موجودی ' + p.qty + ' ' + p.unit, icon: 'box', go: () => navigateTo('inventory') }))]);
    const iv = STORE.invoices.filter(i => norm(i.id + cmpName(i.customer)).includes(q)).slice(0, 4);
    if (iv.length) groups.push(['فاکتورها', 'invoices', iv.map(i => ({ t: i.id + ' — ' + cmpName(i.customer), s: faMoney(i.amount) + ' · ' + i.status, icon: 'doc', go: () => navigateTo('invoices') }))]);
    const ts = STORE.tasks.filter(t => norm(t.title + t.descr).includes(q)).slice(0, 4);
    if (ts.length) groups.push(['وظایف', 'tasks', ts.map(t => ({ t: t.title, s: userOf(t.assignee).name + ' · ' + t.due, icon: 'task', go: () => navigateTo('tasks') }))]);
    const sp = SUPPLIERS.filter(s => norm(s.name + s.product).includes(q)).slice(0, 3);
    if (sp.length) groups.push(['تامین‌کنندگان', 'purchase', sp.map(s => ({ t: s.name, s: s.product, icon: 'cart', go: () => navigateTo('purchase') }))]);
    if (!groups.length) { box.innerHTML = '<div class="sr-empty">${I.search} نتیجه‌ای برای «' + q + '» یافت نشد</div>'; box.classList.add('show'); return; }
    box.innerHTML = groups.map(([label, mod, items]) => `
        <div class="sr-group">${label}</div>
        ${items.map(x => `<div class="sr-item" data-mod="${mod}" data-id="${x.id || ''}">
            <span class="sr-icon">${I[x.icon]}</span>
            <span style="min-width:0"><span class="sr-t">${x.t}</span><div class="sr-s">${x.s || ''}</div></span>
        </div>`).join('')}`).join('');
    box.classList.add('show');
    const handler = function (e) {
        const item = e.target.closest('.sr-item');
        if (!item) return;
        const g = groups.flat();
        const idx = [...box.querySelectorAll('.sr-item')].indexOf(item);
        box.classList.remove('show');
        document.removeEventListener('click', handler);
    };
    setTimeout(() => document.addEventListener('click', handler), 10);
}
function srClick(e) {
    const item = e.target.closest('.sr-item');
    if (!item) return;
    const id = item.dataset.id;
    document.getElementById('searchResults').classList.remove('show');
    if (id) location.hash = '#gentleman';
}
function handleSearchKeydown(e) {
    if (e.key === 'Escape') document.getElementById('searchResults').classList.remove('show');
}

/* ============================================================
   ROUTER
   ============================================================ */
const RENDERERS = {
    dashboard: pageDashboard, customers: pageCustomers, pipeline: pagePipeline,
    purchase: pagePurchase, inventory: pageInventory, invoices: pageInvoices,
    accounting: pageAccounting, checks: pageChecks, tasks: pagesTasks,
    calendar: pageCalendar, reports: pageReports, automation: pageAutomation,
    ai: pageAI, settings: pageSettings, notifications: pageNotifs,
};
const POSTRENDER = {
    dashboard: chartsDashboard, accounting: chartsAccounting, reports: chartsReports, ai: bindAI,
};
function mobileNavigation() {
    const links = [
        ['dashboard', 'داشبورد', 'dash'],
        ['tasks', 'وظایف', 'task'],
        ['customers', 'مشتریان', 'users'],
        ['notifications', 'اعلان‌ها', 'bell'],
    ].filter(([page]) => can(page));
    return `<nav class="mobile-fab-grid" aria-label="پیمایش سریع">${links.map(([page, label, icon]) =>
        `<button type="button" class="fab-item${STORE.page === page ? ' active' : ''}" ${STORE.page === page ? 'aria-current="page"' : ''} onclick="navigateTo('${page}')"><span aria-hidden="true">${I[icon]}</span><span>${label}</span></button>`
    ).join('')}</nav>`;
}
function renderPage() {
    if (!STORE.user) return;
    const page = STORE.page;
    if (!can(page)) { STORE.page = 'dashboard'; renderRouter('dashboard'); showToast('warn', 'دسترسی محدود', 'نقش شما به این بخش دسترسی ندارد'); return; }
    renderRouter(page, true);
}
function renderRouter(page, keepParams) {
    const content = document.getElementById('pageContent');
    content.innerHTML = `<div class="page">${(RENDERERS[page] || (() => '<div class="empty-state">صفحه یافت نشد</div>'))()}</div>` + mobileNavigation();
    if (POSTRENDER[page]) POSTRENDER[page]();
    document.getElementById('topbarTitle').textContent = PAGES[page].title;
    document.getElementById('topbarCrumb').textContent = PAGES[page].crumb;
    document.querySelectorAll('.nav-item').forEach(n => n.classList.toggle('active', n.dataset.page === page));
    content.scrollTop = 0;
    renderSidebar();
}
function navigateTo(page, params) {
    if (!STORE.user) return;
    if (!can(page)) { showToast('warn', 'دسترسی محدود', 'نقش شما به این بخش دسترسی ندارد'); return; }
    STORE.page = page;
    document.getElementById('sidebar').classList.remove('open');
    document.getElementById('sidebarOverlay').classList.remove('show');
    STORE.params = params || {};
    if (page === 'customers' && !params) STORE.params = {};
    if (page === 'tasks' && !STORE.params.view) STORE.params.view = 'kanban';
    if (page === 'calendar' && !STORE.params.month) STORE.params.month = STORE.calMonth;
    renderRouter(page);
}
window.navigateTo = navigateTo;
window.renderPage = renderPage;

/* ============================================================
   LOGIN / LOGOUT
   ============================================================ */
function bindDemoRoles() {
    const box = document.getElementById('demoRoles');
    const users = USERS;
    box.innerHTML = users.filter(u => ['admin', 'sales_manager', 'seller', 'accountant', 'warehouse', 'employee'].includes(u.role)).map(u => `
        <button class="demo-role" id="dr-${u.role}" onclick="loginAs('${u.username}')">
            <span class="dr-dot" style="color:${ROLES[u.role].color}"></span>
            <span>${ROLES[u.role].label}</span>
        </button>`).join('');
}
function loginAs(username) {
    const u = USERS.find(x => x.username === username);
    if (!u) { showToast('error', 'ورود ناموفق', 'نام کاربری یافت نشد'); return; }
    STORE.user = u;
    document.getElementById('loginScreen').style.display = 'none';
    document.getElementById('appLayout').style.display = 'flex';
    systemChecks();
    refreshTopbar();
    renderNotifPanel();
    renderMsgPanel();
    renderSidebar();
    logAudit('وارد سیستم شد (' + ROLES[u.role].label + ')', 'سیستم');
    showToast('success', 'خوش آمدید ' + u.name + ' 👋', 'ورود با نقش «' + ROLES[u.role].label + '» انجام شد');
    navigateTo('dashboard');
}
function handleLogin(e) {
    e.preventDefault();
    const usr = document.getElementById('loginUser').value.trim();
    const pw = document.getElementById('loginPass').value;
    const u = USERS.find(x => x.username === usr || x.name === usr);
    if (!u || u.pass !== pw) { showToast('error', 'ورود ناموفق', 'نام کاربری یا رمز عبور اشتباه است'); return false; }
    loginAs(u.username);
    return false;
}
function togglePass() {
    const p = document.getElementById('loginPass');
    p.type = p.type === 'password' ? 'text' : 'password';
}
function showForgot() {
    showToast('info', 'بازیابی رمز عبور', 'لینک بازیابی به ایمیل سازمانی ارسال شد');
}
function handleLogout() {
    STORE.user = null;
    document.getElementById('appLayout').style.display = 'none';
    document.getElementById('loginScreen').style.display = 'flex';
    showToast('info', 'خروج از سیستم', 'جلسه شما امن بسته شد');
}
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('open');
    document.getElementById('sidebarOverlay').classList.toggle('show');
}

/* ============================================================
   KEYBOARD
   ============================================================ */
document.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); document.getElementById('globalSearch').focus(); }
    if (e.key === 'Escape') {
        closeModal();
        document.getElementById('sidebar').classList.remove('open');
        document.getElementById('sidebarOverlay').classList.remove('show');
    }
});

/* ============================================================
   INIT
   ============================================================ */
window.addEventListener('load', () => {
    bindDemoRoles();
    document.getElementById('globalSearch').addEventListener('input', e => handleGlobalSearch(e.target.value));
    document.getElementById('searchResults').addEventListener('click', e => {
        const item = e.target.closest('.sr-item');
        if (!item) return;
        document.getElementById('searchResults').classList.remove('show');
        const mod = item.dataset.mod;
        if (mod) navigateTo(mod);
    });
});
