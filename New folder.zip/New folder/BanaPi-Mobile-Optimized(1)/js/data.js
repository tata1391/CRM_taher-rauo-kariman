/* ============================================
   بناپی — Seed Data & Business Config
   داده‌های نمونه حذف شدند — سیستم از صفر شروع می‌کند.
   فقط ساختار (کاربران، نقش‌ها، دسترسی‌ها، کاتالوگ کالا،
   مراحل، دسته‌بندی‌ها و تنظیمات اتوماسیون) حفظ شده است.
   ============================================ */

const BANAPI = {
    version: '2.4.0',
    company: 'بازرگانی فولاد و سیمان بنا پی',
    currency: 'تومان',
    currencyShort: 'تومان',
    todayKey: function () { return '2026-09-23'; },
};

/* ---------- Users & Roles ---------- */
const ROLES = {
    admin:        { label: 'مدیر کل',      color: '#00C8FF', icon: 'crown' },
    sales_manager:{ label: 'مدیر فروش',    color: '#8B5CF6', icon: 'chart' },
    seller:       { label: 'فروشنده',      color: '#F59E0B', icon: 'hand' },
    accountant:   { label: 'حسابدار',      color: '#10B981', icon: 'calc' },
    warehouse:    { label: 'انباردار',     color: '#F43F5E', icon: 'box' },
    employee:     { label: 'کارمند',       color: '#64748B', icon: 'user' },
};

const PERMISSIONS = {
    admin:         ['dashboard','customers','pipeline','purchase','inventory','invoices','accounting','checks','tasks','calendar','reports','automation','ai','settings','notifications','users','audit'],
    sales_manager: ['dashboard','customers','pipeline','purchase','inventory','invoices','tasks','calendar','reports','ai','notifications','settings'],
    seller:        ['dashboard','customers','pipeline','tasks','calendar','ai','notifications','settings'],
    accountant:    ['dashboard','invoices','accounting','checks','purchase','reports','ai','notifications','settings'],
    warehouse:     ['dashboard','inventory','purchase','tasks','reports','ai','notifications','settings'],
    employee:      ['dashboard','tasks','calendar','notifications','ai','settings'],
};

const USERS = [
    { id:'u1',  name:'امیر حسینی',  role:'admin',         username:'admin',  pass:'123456', initials:'ا', phone:'09120011223' },
    { id:'u2',  name:'رضا محمدی',   role:'sales_manager', username:'rmohamadi', pass:'123456', initials:'ر', phone:'09123334455' },
    { id:'u3',  name:'علی احمدی',   role:'seller',        username:'ahmadi', pass:'123456', initials:'ع', phone:'09124445566' },
    { id:'u4',  name:'مریم کریمی',  role:'accountant',    username:'karimi', pass:'123456', initials:'م', phone:'09352223344' },
    { id:'u5',  name:'حسین رضایی',  role:'warehouse',     username:'rezaei', pass:'123456', initials:'ح', phone:'09125556677' },
    { id:'u6',  name:'سارا موسوی',  role:'employee',      username:'mousavi', pass:'123456', initials:'س', phone:'09366678899' },
];

/* ---------- Customers (CRM lifecycle) ---------- */
const CRM_STAGES = [
    { key:'new',       label:'مشتری جدید',   color:'#38BDF8' },
    { key:'contacted', label:'تماس اولیه',   color:'#60A5FA' },
    { key:'need',      label:'نیازسنجی',     color:'#818CF8' },
    { key:'quoted',    label:'ارسال قیمت',   color:'#C084FC' },
    { key:'negotiate', label:'مذاکره',       color:'#F0ABFC' },
    { key:'approval',  label:'تایید خرید',   color:'#FBBF24' },
    { key:'active',    label:'مشتری فعال',   color:'#34D399' },
];

/* هیچ مشتری‌ای ثبت نشده است */
const CUSTOMERS = [];

/* ---------- Suppliers ---------- */
/* لیست تامین‌کنندگان خالی است */
const SUPPLIERS = [];

/* ---------- Product features (واحد فروش / نوع عرضه) ---------- */
const PRODUCT_FEATURES = [
    { key: 'ton',    label: 'تناژی (وزنی)',     icon: 'scale' },
    { key: 'count',  label: 'ظرفیتی (عددی)',    icon: 'box' },
    { key: 'bag',    label: 'پاکتی (کیسه‌ای)',  icon: 'cube' },
    { key: 'sheet',  label: 'ورقی',             icon: 'layers' },
];

/* ---------- Products / Inventory ---------- */
const PRODUCTS = [
    { id:'p1',  name:'میلگرد ۱۴',        cat:'میلگرد',  unit:'شاخه',  qty:0,  minStock:900,   weight:29.5,  buyPrice:0,  avgCost:0,  sellPrice:0,  status:'ok',    features:['count','ton'], trend:[0,0,0,0,0,0,0,0] },
    { id:'p2',  name:'میلگرد ۱۶',        cat:'میلگرد',  unit:'شاخه',  qty:0,  minStock:600,   weight:38.5,  buyPrice:0,  avgCost:0,  sellPrice:0,  status:'ok',    features:['count','ton'], trend:[0,0,0,0,0,0,0,0] },
    { id:'p3',  name:'میلگرد ۲۰',        cat:'میلگرد',  unit:'شاخه',  qty:0,  minStock:700,   weight:59,    buyPrice:0,  avgCost:0,  sellPrice:0,  status:'ok',    features:['count','ton'], trend:[0,0,0,0,0,0,0,0] },
    { id:'p4',  name:'تیرآهن ۱۶',        cat:'پروفیل',  unit:'شاخه',  qty:0,  minStock:150,   weight:160,   buyPrice:0,  avgCost:0,  sellPrice:0,  status:'ok',    features:['count','ton'], trend:[0,0,0,0,0,0,0,0] },
    { id:'p5',  name:'نبشی ۵',           cat:'پروفیل',  unit:'شاخه',  qty:0,  minStock:400,   weight:31,    buyPrice:0,  avgCost:0,  sellPrice:0,  status:'ok',    features:['count','ton'], trend:[0,0,0,0,0,0,0,0] },
    { id:'p6',  name:'ناودانی ۶',        cat:'پروفیل',  unit:'شاخه',  qty:0,  minStock:350,   weight:47,    buyPrice:0,  avgCost:0,  sellPrice:0,  status:'ok',    features:['count','ton'], trend:[0,0,0,0,0,0,0,0] },
    { id:'p7',  name:'ورق سیاه ۲ میل',    cat:'ورق',     unit:'ورق',   qty:0,  minStock:200,   weight:150,   buyPrice:0,  avgCost:0,  sellPrice:0,  status:'ok',    features:['sheet','ton'], trend:[0,0,0,0,0,0,0,0] },
    { id:'p8',  name:'سیمان تیپ ۲ (۵۰ کیلویی)', cat:'سیمان', unit:'پاکت', qty:0, minStock:3000,  weight:50,    buyPrice:0,  avgCost:0,  sellPrice:0,  status:'ok',    features:['bag','ton'], trend:[0,0,0,0,0,0,0,0] },
    { id:'p9',  name:'سیمان فله',        cat:'سیمان',   unit:'تن',    qty:0,  minStock:25,    weight:1000,  buyPrice:0,  avgCost:0,  sellPrice:0,  status:'ok',    features:['ton'], trend:[0,0,0,0,0,0,0,0] },
    { id:'p10', name:'میلگرد ۱۲',        cat:'میلگرد',  unit:'شاخه',  qty:0,  minStock:1200,  weight:21.5,  buyPrice:0,  avgCost:0,  sellPrice:0,  status:'ok',    features:['count','ton'], trend:[0,0,0,0,0,0,0,0] },
];

/* ---------- Invoices ---------- */
/* هیچ فاکتوری ثبت نشده است */
const INVOICES = [];

/* ---------- Checks ---------- */
/* هیچ چکی ثبت نشده است */
const CHECKS = [];

/* ---------- Sales Pipeline ---------- */
const PIPELINE_STAGES = [
    { key:'new',       label:'مشتری جدید',   color:'#38BDF8', value:0 },
    { key:'contacted', label:'تماس انجام شد', color:'#60A5FA', value:0 },
    { key:'quoted',    label:'ارسال قیمت',    color:'#818CF8', value:0 },
    { key:'negotiate', label:'مذاکره',        color:'#C084FC', value:0 },
    { key:'approval',  label:'تایید خرید',    color:'#FBBF24', value:0 },
    { key:'won',       label:'تکمیل شده',     color:'#34D399', value:0 },
];

/* هیچ فرصت فروشی ثبت نشده است */
const DEALS = [];

/* ---------- Tasks ---------- */
/* هیچ وظیفه‌ای ثبت نشده است */
const TASKS = [];

/* ---------- Monthly series (for charts) ---------- */
const MONTHS = ['فرو','ارد','خرد','تیر','مرد','شهر','مهر','آبا','آذر','دی','بهم','اسف'];
const SERIES = {
    sales:      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    purchases:  [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    profit:     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    customers:  [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    inflow:     [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    outflow:    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
};

const EXPENSE_CATS = [
    { label:'خرید کالا',      value: 0, color:'#0B7BFF' },
    { label:'حمل و نقل',      value: 0, color:'#00C8FF' },
    { label:'دستمزد',        value: 0, color:'#7C6CFF' },
    { label:'تخفیف مشتری',    value: 0, color:'#E184FF' },
    { label:'هزینه‌های اداری', value: 0, color:'#38BDF8' },
    { label:'سایر',          value: 0, color:'#64748B' },
];

const INCOME_CATS = [
    { label:'فروش میلگرد',   value: 0, color:'#0B7BFF' },
    { label:'فروش پروفیل',   value: 0, color:'#00C8FF' },
    { label:'فروش سیمان',    value: 0, color:'#7C6CFF' },
    { label:'ورق و سایر',    value: 0, color:'#38BDF8' },
];

/* ---------- Notifications ---------- */
/* اعلان جدیدی وجود ندارد */
const NOTIFS = [];

const MESSAGES = [];

/* ---------- Automation Workflows ---------- */
const WORKFLOWS = [
    {
        id:'wf1', name:'پیگیری مشتری جدید', enabled:true, trigger:'مشتری جدید ایجاد شد',
        nodes:[
            { type:'trigger', icon:'users',   label:'WHEN', text:'مشتری جدید ایجاد شد', color:'#38BDF8' },
            { type:'action',  icon:'task',    label:'THEN', text:'ایجاد وظیفه پیگیری مشتری', color:'#7C6CFF' },
            { type:'action',  icon:'bell',    label:'THEN', text:'اعلان به مدیر فروش', color:'#00C8FF' },
            { type:'action',  icon:'clock',   label:'THEN', text:'زمان‌بندی تماس پس از ۳ روز', color:'#34D399' },
        ],
    },
    {
        id:'wf2', name:'هشدار فاکتور معوق ۳۰ روزه', enabled:true, trigger:'فاکتور ۳۰ روز پرداخت نشده',
        nodes:[
            { type:'trigger', icon:'doc',     label:'WHEN', text:'فاکتور بعد از ۳۰ روز پرداخت نشد', color:'#F43F5E' },
            { type:'action',  icon:'coin',    label:'THEN', text:'اعلان به حسابدار', color:'#10B981' },
            { type:'action',  icon:'task',    label:'THEN', text:'ایجاد وظیفه وصول مطالبات', color:'#F59E0B' },
            { type:'action',  icon:'sms',     label:'THEN', text:'ارسال پیام یادآوری به مشتری', color:'#8B5CF6' },
        ],
    },
    {
        id:'wf3', name:'هشدار کاهش موجودی انبار', enabled:true, trigger:'موجودی زیر حد مجاز',
        nodes:[
            { type:'trigger', icon:'box',     label:'WHEN', text:'موجودی کالا زیر حد مجاز شد', color:'#00C8FF' },
            { type:'action',  icon:'bell',    label:'THEN', text:'اعلان به انباردار', color:'#38BDF8' },
            { type:'action',  icon:'cart',    label:'THEN', text:'ایجاد درخواست خرید خودکار', color:'#7C6CFF' },
            { type:'action',  icon:'doc',     label:'THEN', text:'ارسال درخواست به تامین‌کننده', color:'#34D399' },
        ],
    },
];

/* ---------- Audit log ---------- */
/* گزارش عملیات خالی است */
const AUDIT_LOG = [];

/* ---------- User activity / performance (reports) ---------- */
const EMP_PERF = [];

/* ---------- Meetings / Calendar events ---------- */
/* جلسه‌ای ثبت نشده است */
const MEETINGS = [];