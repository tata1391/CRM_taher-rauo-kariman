from pathlib import Path
import re
root = Path(__file__).parent
html = (root/'index.html').read_text()
html = re.sub(r'<style>.*?</style>', '<style>\n'+(root/'css/styles.css').read_text()+'\n</style>', html, count=1, flags=re.S)
html = re.sub(r'\s*<script src="\./js/(?:data|app)\.js\?v=[^"]+"></script>', '', html)
scripts = ['<script>\n'+(root/'js'/name).read_text()+'\n</script>' for name in ['data.js','app.js']]
html = re.sub(r'<script>.*?</script>\s*<script>.*?</script>', lambda m: '\n'.join(scripts), html, count=1, flags=re.S)
for name in ['index.html','index-mobile.html']:
    (root/name).write_text(html)
