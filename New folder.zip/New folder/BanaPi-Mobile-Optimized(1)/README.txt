اجرای پروژه بناپی
=================

روش پیشنهادی:
1) کل پوشه پروژه را Extract کن.
2) روی START.bat دوبار کلیک کن.
3) مرورگر روی http://127.0.0.1:8000 باز می‌شود.

روش دوم:
index.html را با VS Code و افزونه Live Server اجرا کن.

ساختار:
index.html
css/styles.css
js/data.js
js/app.js
server.py
START.bat

Chart.js اختیاری است؛ اگر CDN در دسترس نباشد، خود برنامه و CSS همچنان اجرا می‌شوند و فقط نمودارها نمایش داده نمی‌شوند.
